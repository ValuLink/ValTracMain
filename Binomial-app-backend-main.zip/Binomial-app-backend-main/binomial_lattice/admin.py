from django.contrib import admin
from .models import BinomialLattice
# Register your models here.
admin.site.register(BinomialLattice)