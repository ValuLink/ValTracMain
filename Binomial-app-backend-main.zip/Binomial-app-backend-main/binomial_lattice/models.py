from django.db import models
from django.contrib.auth.models import User
from valuation_creator.models import Valuation
from accounts.models import Agent

# Create your models here.
# BinomialLattice Creative
class BinomialLattice(models.Model):
    # Instrument
    stock_values = models.TextField(max_length=100000, blank=True)
    solution_values = models.TextField(max_length=100000, blank=True)
    note_values = models.TextField(max_length=100000, blank=True)
    conversion_values = models.TextField(max_length=100000, blank=True)
    straight_debt_values = models.TextField(max_length=100000, blank=True)
    truncated_stock_values = models.TextField(max_length=100000, blank=True)
    truncated_solution_values = models.TextField(max_length=100000, blank=True)
    truncated_note_values = models.TextField(max_length=100000, blank=True)
    truncated_conversion_values = models.TextField(max_length=100000, blank=True)
    truncated_straight_debt_values = models.TextField(max_length=100000, blank=True)
    upload_time = models.DateTimeField(auto_now_add=True, null=True)
    #Corresponds to user Id
    valuation = models.ForeignKey(Valuation,
                             related_name="BinomialLattice",
                             on_delete=models.CASCADE,
                             null=True)
    agent = models.ForeignKey(Agent,
                             related_name="BinomialLattice",
                             on_delete=models.CASCADE,
                             null=True)
    user = models.ForeignKey(User,
                             related_name="BinomialLattice",
                             on_delete=models.CASCADE,
                             null=True)

    class Meta:
        verbose_name = 'BinomialLattice'
