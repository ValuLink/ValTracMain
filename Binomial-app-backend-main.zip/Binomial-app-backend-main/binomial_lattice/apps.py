from django.apps import AppConfig


class BinomialLatticeConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'binomial_lattice'
