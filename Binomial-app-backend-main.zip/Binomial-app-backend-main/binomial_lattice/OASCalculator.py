import requests
import pandas as pd
from valtrak.settings import ICE_USERNAME, ICE_PASSWORD

class OASCalculator:
    def get(self):
        # make a request to the API
        headers = self.auth()
        url = 'https://api.theice.com/option-valuation-service/v1/oas'
        response = requests.get(url, headers=headers)
        
        # extract OAS data using pandas
        data = response.json()
        df = pd.DataFrame(data)
        oas_data = df[['optionSymbol', 'oas']]
        
        # serialize the data into JSON format and return the response
        return oas_data.to_dict()
    def auth(self):
        username = ICE_USERNAME
        password = ICE_PASSWORD
        auth_url = 'https://api.theice.com/token'

        response = requests.post(auth_url, data={
            'grant_type': 'client_credentials',
            'client_id': username,
            'client_secret': password
        })
        access_token = response.json().get('access_token')
        headers = {
            'Authorization': f'Bearer {access_token}',
            'Content-Type': 'application/json'
        }
        return headers
