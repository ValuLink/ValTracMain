from django.urls import path
from . import views
from django.views.decorators.csrf import csrf_exempt
from rest_framework import routers
from .api import BinomialLatticeViewSet, AgentBinomialLatticeViewSet

# Register api Routes
router = routers.DefaultRouter()
router.register('binomial-lattice', BinomialLatticeViewSet, 'binomial-lattice')
router.register('agent-binomial-lattice', AgentBinomialLatticeViewSet, 'agent-binomial-lattice')

urlpatterns = router.urls + [
  path('create-binomial-lattice/',
    csrf_exempt(views.create_binomial_lattice),
    name='create-binomial-lattice'),
]
