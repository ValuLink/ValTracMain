from rest_framework import serializers
from .models import BinomialLattice


# BinomialLattice Serializer
class BinomialLatticeSerializer(serializers.ModelSerializer):
    class Meta:
        model = BinomialLattice
        # fields = '__all__'
        fields = [
            'id',
            'stock_values',
            'solution_values',
            'note_values',
            'conversion_values',
            'straight_debt_values',
            'truncated_stock_values',
            'truncated_solution_values',
            'truncated_note_values',
            'truncated_conversion_values',
            'truncated_straight_debt_values',
            'valuation',
            'upload_time',
            'user',
            'agent',
        ]
        extra_kwargs = {
            'id': {
                'required': False
            },
            'stock_values': {
                'required': False
            },
            'solution_values': {
                'required': False
            },
            'note_values': {
                'required': False
            },
            'conversion_values': {
                'required': False
            },
            'straight_debt_values': {
                'required': False
            },
            'truncated_stock_values': {
                'required': False
            },
            'truncated_solution_values': {
                'required': False
            },
            'truncated_note_values': {
                'required': False
            },
            'truncated_conversion_values': {
                'required': False
            },
            'truncated_straight_debt_values': {
                'required': False
            },
            'valuation': {
                'required': False
            },
            'upload_time': {
                'required': False
            },
            'user': {
                'required': False
            },
            'agent': {
                'required': False
            }
        }
        validators = []

