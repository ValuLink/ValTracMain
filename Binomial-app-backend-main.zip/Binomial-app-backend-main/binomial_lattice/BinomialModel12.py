# This program creates a binomial lattice model using the CRR model for American Option Valuation

# Author: Ray Clark & Andrew Hoang
# Binomial tree (Cox-Rox-Rubenstein) for American Option Valuation

# Inspired from:
# Binomial Tree for America and European options by Mehdi Bounouar
# Binomial Tree Option Valuation Cox, Ross, Rubinstein method by "www.quantandfinancial.com"
#import sys
# import matplotlib.pyplot as plt
import numpy as np
import json

from win32com import client
import pythoncom
#from numpy import inf
#import datetime
#from datetime import date
import openpyxl
import os
from .models import BinomialLattice
from valuation_creator.models import Valuation
from .NumpyArrayEncoder import NumpyArrayEncoder
from reportlab.lib.pagesizes import letter
from reportlab.lib.units import inch
from reportlab.platypus import SimpleDocTemplate, Spacer, Paragraph, Table, TableStyle
from reportlab.lib.styles import getSampleStyleSheet
from .InterestCalculator import InterestCalculator
from datetime import datetime


#######################################
#####binomial Option Pricing Model#####
#######################################

class Binomial:
    def __init__(self, note_val, ex_price, conv_shares, stock_price, trigger, num_years, num_days1, num_days2, ann_vol, 
        ann_int1, ann_int2, interest_compounds_nodes, interest_per_accrual, cash_interest_per_accrual, accrual_frequency, user, valuation_id, company_name, mandatory_conversion_percent_condition, mandatory_conversion_percentage, fixed_conversion_price, trading_days_list, fx_rate, monthly_interval, monthly_interest, monthly_cash_interest, inception_trading_days_list, inception_to_valuation_delta, valuation_date, maturity_date, credit_spread, interest_case, accrual_indices):
        self.valuation_date = valuation_date #principal per note
        self.maturity_date = maturity_date #principal per note
        self.note_val = note_val #principal per note
        self.ex_price = ex_price #conversion price
        self.conv_shares = conv_shares #original conversion shares
        self.stock_price = stock_price #starting stock price
        self.trigger = trigger #conversion share trigger price
        self.num_years = num_years #number of years to maturity
        self.num_days1 = num_days1 #calendar days to maturity
        self.steps = num_days2 #'trading days' to maturity = steps in lattice
        self.ann_vol = ann_vol/100 #annual volatility
        self.fx_rate = fx_rate #fx_rate
        self.ann_int1 = ann_int1 #annual risk-free interest rate
        self.ann_int2 = ann_int2 #annual yeild to maturity, market rate of interest
        self.credit_spread = credit_spread #annual yeild to maturity, market rate of interest
        self.monthly_interval = monthly_interval #annual yeild to maturity, market rate of interest
        self.monthly_interest = monthly_interest #annual yeild to maturity, market rate of interest
        self.monthly_cash_interest = monthly_cash_interest #annual yeild to maturity, market rate of interest
        self.mandatory_conversion_percent_condition = mandatory_conversion_percent_condition #Bool condition of mandatory conversion at a percentage threshold
        if mandatory_conversion_percent_condition == 'true':
            self.mandatory_conversion_val = float(mandatory_conversion_percentage) * float(fixed_conversion_price) #Trigger percentage for mandatory conversion percent condition
        # self.interest_rate_data = interest_rate_data #annual yeild to maturity, market rate of interest
        # self.stock_prices_data = stock_prices_data #annual yeild to maturity, market rate of interest
        self.interest_compounds_nodes = interest_compounds_nodes #number of nodes between each interest accrual
        self.interest_per_accrual = interest_per_accrual #interest accrued at each accrual
        self.cash_interest_per_accrual = cash_interest_per_accrual #interest accrued at each accrual
        self.accrual_frequency = accrual_frequency #interest accrued at each accrual
        self.CF = 0.75 #conversion shares factor
        self.user = user #conversion shares factor
        self.valuation_id = valuation_id #conversion shares factor
        self.company_name = company_name #conversion shares factor
        self.trading_days_list = trading_days_list #List of trading date strings in time period
        self.inception_trading_days_list = inception_trading_days_list #List of trading date strings in time period
        self.inception_to_valuation_delta = inception_to_valuation_delta #List of trading date strings in time period
        self.interest_case = interest_case #List of trading date strings in time period
        self.accrual_indices = accrual_indices #List of trading date strings in time period
        # self.accrual_index_one = accrual_index_one #List of trading index strings in time period
        # self.accrual_date_two = accrual_date_two #List of trading date strings in time period
        # self.accrual_index_two = accrual_index_two #List of trading index strings in time period
        
        #Avoid Dividing by zero
        #if (self.steps == 0):
         #   self.t_step = 0   #time step
        #else: 
        self.t_step = self.num_years/self.steps #Time Step in years
        self.u = np.exp(self.ann_vol * np.sqrt(self.t_step)) #up factor
        # print("self.ann_vol:::::", self.ann_vol)
        # print("self.t_step:::::", self.t_step)
        # print("self.u:::::", self.u)
        self.d = 1./self.u #down factor
        # print("self.d:::::", self.d)
        self.p1 = (np.exp(self.ann_int1 * self.t_step)-self.d) / (self.u-self.d) #up probability
        self.p2 = 1 - self.p1 #down probability
        self.stockvalue = np.zeros((int(self.steps)+1, int(self.steps)+1), dtype=np.float64) #Array of stock values to be populated
        self.note_vals_list = np.zeros((int(self.steps)+1, 3), dtype=np.float64) #Initialize straight debt array

        
    #Create Binomial price tree here    
    def calculate(self):
        # self.calculate_volatility()
        self.stockvalue[0,0] = self.stock_price #set initital stock price
        for i in range(0, int(self.steps)+1): #Iterate over rows in stockvalues
            row=i
            for j in range(1,int(self.steps)+1): #iterate over columns in stock values 
                column = j
                if self.stockvalue[column-1, row] == 0: #Check if previous node is 0
                    if self.stockvalue[column-1, row-1] != 0: #check if previous node one column over is not zero
                        self.stockvalue[column, row] = round(self.stockvalue[column-1, row-1]*self.d, 3) #down value price
                else:
                    # if column == 1 and row == 0:
                    #     print("column == 1 and row == 0 CASE 2", self.stockvalue[column-1, row])
                    self.stockvalue[column, row] = round(self.stockvalue[column-1, row] * self.u, 3) #up value price
        # print(self.stockvalue)
        
        return self.binomial_valuation() #call valuation method - see line 116

    # #Create Binomial price tree here    
    # def calculate_volatility(self):
    #     num_stocks = len(self.stock_prices_data)
    #     annualized_volatility_list = []

    #     for stock in range (0, num_stocks):
    #         volatility_list = np.zeros(int(self.num_days1), dtype=np.float64)
    #         print('LIST LENGTH', len(self.stock_prices_data))
    #         # print("self.stock_prices_data[stock]['Time Series (Daily)']", self.stock_prices_data[stock]['Time Series (Daily)'])
    #         stock_price_date_list = list(self.stock_prices_data[stock]['Time Series (Daily)'].keys())

    #         stock_price_dict = self.stock_prices_data[stock]['Time Series (Daily)']
    #         # print('DATES LIST !!!!', stock_price_date_list, type(stock_price_date_list))
    #         for val in range (0, volatility_list[0].size):
    #             date = stock_price_date_list[val+1]
    #             previous_date = stock_price_date_list[val+2]
    #             # print('DATES!!!!', previous_date, stock_price_dict[date], type(stock_price_dict[date]))
    #             log_val = math.log(float(stock_price_dict[date]['5. adjusted close'])/float(stock_price_dict[previous_date]['5. adjusted close']))
    #             # volatility_list[0][val] = val
    #             # volatility_list[1][val] = date_list[val]
    #             volatility_list[val] = log_val
    #         annualized_volatility_list.append(np.std(volatility_list)*math.sqrt(252))
    #     print("annualized_volatility list!!!!", len(annualized_volatility_list), annualized_volatility_list)
    #     average_annual_volatility = np.sum(annualized_volatility_list)/len(annualized_volatility_list)
    #     print("average_annual_volatility!!!!", average_annual_volatility)
    #     return average_annual_volatility #call valuation method - see line 116

    def truncate(self, arr):
        # rows = list(range(5))
        # rows.extend(range(-5, 0))
        # cols = [i for i in range(5)]
        # cols.extend([-i-1 for i in range(5)])
        # new_arr = arr[rows, cols]
        # print("NEW ARRAY", new_arr)
        new_list = np.transpose(arr).tolist()
        if len(new_list) > 3:
            truncated_rows = new_list[:5] + new_list[-5:]
            # last_rows = new_list[-5:]
            # truncated_rows.extend(last_rows)
        else:
            truncated_rows = new_list
        truncated_list = []
        for row in truncated_rows:
            values_one = row[0:5]
            values_two = row[-5:]
            new_row = values_one + values_two
            truncated_list.append(new_row)
        # reversed_list = truncated_list[::-1]
        # reversed_list = truncated_list.reverse()
        # truncated_list.reverse()
        # for sublist in truncated_list:
        #     sublist.reverse()
        return truncated_list

    def create_pdf(self, pdf_stock_vals_title, truncated_stock_vals, pdf_note_val_title, truncated_note_vals, pdf_conv_val_title, truncated_conversion_vals, pdf_straight_debt_title, truncated_debt_vals, pdf_solution_title, truncated_solution_val, present_value):
        title = "Valuation of {} Convertable Notes".format(self.company_name)
        body_text = 'GT noted that the instruments were convertible into common shares of the Company and had liquidity preference over other classes of common stock issued by the Company, and therefore the Option Pricing Method (“OPM”) for determining the fair value of these instruments was applied. Under the OPM, each class of stock was modelled as a call option with a distinct claim on the enterprise value of the Company. The option’s exercise price was based on a comparison with the enterprise value. The characteristics of each class of stock, including the conversion ratio and any liquidation preference, determined the class of stock’s claim on the enterprise value of the Company. As per the OPM, if, at any time of a liquidity event, the equity value was less than the total liquidation preference of the preferred stock, the value of the common stock would be zero. If the equity value exceeded the total liquidation preference, the proceeds after paying the liquidation preference would satisfy the common shareholders. If certain classes of common stock were convertible into common shares, the OPM incorporated the equity value (‘breakeven point’) required for the holders to exercise the conversion option and acquire common shares. The OPM used a ‘waterfall’ approach for allocating a distinct claim on the equity value to each class of common stock based on the liquidity preference (based on the order of receiving the liquidation value) and conversion scenarios (by incorporating equity value scenarios where the convertible instruments convert into common shares).'
        doc = SimpleDocTemplate(title + '.pdf', pagesize=letter)

        # Define the styles
        styles = getSampleStyleSheet()
        header_style = styles['Heading1']
        header_style.backColor = 'lightgrey'  # set the background color
        body_style = styles['Normal']

        # Create the story
        story = []

        # Add the title as a header
        story.append(Paragraph(title, header_style))
        story.append(Spacer(1, 0.5 * inch))
        trading_days_list = self.trading_days_list #List of trading date strings in time period
        # VAL Inputs Section
        variables = [self.note_val, self.ex_price, self.conv_shares, self.stock_price, self.trigger, self.num_years, self.num_days1, self.steps, self.ann_vol, self.ann_int1, self.ann_int2, self.interest_compounds_nodes, self.interest_per_accrual, self.cash_interest_per_accrual, self.accrual_frequency, self.CF, self.company_name, present_value]
        labels = ['Note Value', 'Conversion Price', 'Original Conversion Shares', 'Starting Stock Price', 'Conversion Share Trigger Price', 'Number of Years to Maturity', 'Calendar Days to Maturity', 'Trading Days to Maturity', 'Annual Volatility', 'Annual Risk-free Interest Rate', 'Annual Yield to Maturity', 'Number of Nodes between each Interest Accrual', 'Interest Accrued at each Accrual', 'Cash Interest Accrued at each Accrual', 'Accrual Frequency', 'Conversion Shares Factor', 'Company Name', "Present Value"]
        # Create the table
        data = [[Paragraph(labels[i], body_style), Paragraph(str(variables[i]), body_style)] for i in range(len(variables))]
        table = Table(data)


        # Add the section title
        
        story.append(Paragraph("Valuation Inputs", header_style))
        story.append(Spacer(1, 0.5 * inch))

        # Add the table
        story.append(table)
        story.append(Spacer(1, 0.5 * inch))



        # Add the body text
        story.append(Paragraph(body_text, body_style))
        story.append(Spacer(1, 0.5 * inch))



        # Add the tables
        # Add the title as a header
        story.append(Paragraph(pdf_stock_vals_title, header_style))
        story.append(Spacer(1, 0.5 * inch))
        # stock_table_data = [['00', '01', '02', '03', '04'],
        # ['10', '11', '12', '13', '14'],
        # ['20', '21', '22', '23', '24'],
        # ['30', '31', '32', '33', '34']]
        # stock_table_data = self.stockvalue[:5] + self.stockvalue[-5:]
        # stock_table_data = self.stockvalue.tolist()

        # convert the new array into a list of lists using numpy's tolist() method
        # stock_table_data = stock_val_arr.tolist()
        # Create the list of column labels
        # col_labels = [Paragraph(day, getSampleStyleSheet()['Normal']) for day in trading_days_list]

        # Create the list of row labels
        # row_labels = [Paragraph(str(i+1), getSampleStyleSheet()['Normal']) for i in range(len(truncated_stock_vals))]
        # row_labels = [str(i+1) for i in range(len(truncated_stock_vals))]

        # Create the table with column and row labels
        # table_data = [[row_labels[i]] + truncated_stock_vals[i] for i in range(len(truncated_stock_vals))]
        col_labels = [str(trading_days_list[i]) for i in range(5)]
        for i in range(len(trading_days_list)-6, len(trading_days_list)-1):
            col_labels.append(str(trading_days_list[i]))
        # table = Table(table_data, colWidths=[0.65*inch]*(len(trading_days_list)+1), rowHeights=30)
        table_data = [col_labels] + truncated_stock_vals
        table = Table(table_data, colWidths=[0.80*inch]*10, rowHeights=30)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), 'grey'),
            ('TEXTCOLOR', (0, 0), (-1, 0), 'white'),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), 'lightgrey'),
            ('TEXTCOLOR', (0, 1), (-1, -1), 'black'),
            ('ALIGN', (0, 1), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, 'black'),
            ('WORDWRAP', (0, 1), (-1, -1), 'default')
        ]))
        
        story.append(table)
        story.append(Spacer(1, 0.5 * inch))


        # Add the title as a header
        story.append(Paragraph(pdf_conv_val_title, header_style))
        story.append(Spacer(1, 0.5 * inch))
        # conv_table_data = encodedConversionVals.tolist()
        table_data = [col_labels] + truncated_conversion_vals
        table = Table(table_data, colWidths=[0.80*inch]*10, rowHeights=30)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), 'grey'),
            ('TEXTCOLOR', (0, 0), (-1, 0), 'white'),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), 'lightgrey'),
            ('TEXTCOLOR', (0, 1), (-1, -1), 'black'),
            ('ALIGN', (0, 1), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, 'black'),
            ('WORDWRAP', (0, 1), (-1, -1), 'default')
        ]))
        story.append(table)
        story.append(Spacer(1, 0.5 * inch))

        # Add the title as a header
        story.append(Paragraph(pdf_note_val_title, header_style))
        story.append(Spacer(1, 0.5 * inch))
        # note_table_data = encodedNoteVals.tolist()
        # table_data = [col_labels] + truncated_note_vals
        table = Table(truncated_note_vals, colWidths=[0.80*inch]*10, rowHeights=30)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), 'grey'),
            ('TEXTCOLOR', (0, 0), (-1, 0), 'white'),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), 'lightgrey'),
            ('TEXTCOLOR', (0, 1), (-1, -1), 'black'),
            ('ALIGN', (0, 1), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, 'black'),
            ('WORDWRAP', (0, 1), (-1, -1), 'default')
        ]))
        
        story.append(table)
        story.append(Spacer(1, 0.5 * inch))

        # Add the title as a header
        story.append(Paragraph(pdf_straight_debt_title, header_style))
        story.append(Spacer(1, 0.5 * inch))
        # debt_table_data = encodedStraigtDebt.tolist()
        table_data = [col_labels] + truncated_debt_vals
        table = Table(table_data, colWidths=[0.80*inch]*10, rowHeights=30)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), 'grey'),
            ('TEXTCOLOR', (0, 0), (-1, 0), 'white'),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), 'lightgrey'),
            ('TEXTCOLOR', (0, 1), (-1, -1), 'black'),
            ('ALIGN', (0, 1), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, 'black'),
            ('WORDWRAP', (0, 1), (-1, -1), 'default')
        ]))
        story.append(table)
        story.append(Spacer(1, 0.5 * inch))

        # Add the title as a header
        story.append(Paragraph(pdf_solution_title, header_style))
        story.append(Spacer(1, 0.5 * inch))
        # sol_table_data = encodedSolutionVals.tolist()
        table_data = [col_labels] + truncated_solution_val
        table = Table(table_data, colWidths=[0.80*inch]*10, rowHeights=30)
        table.setStyle(TableStyle([
            ('BACKGROUND', (0, 0), (-1, 0), 'grey'),
            ('TEXTCOLOR', (0, 0), (-1, 0), 'white'),
            ('ALIGN', (0, 0), (-1, 0), 'CENTER'),
            ('FONTNAME', (0, 0), (-1, 0), 'Helvetica-Bold'),
            ('FONTSIZE', (0, 0), (-1, 0), 10),
            ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
            ('BACKGROUND', (0, 1), (-1, -1), 'lightgrey'),
            ('TEXTCOLOR', (0, 1), (-1, -1), 'black'),
            ('ALIGN', (0, 1), (-1, -1), 'CENTER'),
            ('FONTNAME', (0, 1), (-1, -1), 'Helvetica'),
            ('FONTSIZE', (0, 1), (-1, -1), 5),
            ('BOTTOMPADDING', (0, 1), (-1, -1), 8),
            ('GRID', (0, 0), (-1, -1), 1, 'black'),
            ('WORDWRAP', (0, 1), (-1, -1), 'default')
        ]))
        story.append(table)
        story.append(Spacer(1, 0.5 * inch))
        # Build the PDF
        doc.build(story)



    def generate_excel_lattice(self, vals, title):
        #print binomial tree results to Excel
        #transpose arrays

        wb = openpyxl.Workbook() #Create new workbook
        sheet = wb.active #Create an active sheet

        col = 0 #column indicator
        for element in vals: #interates over each array element in stockvalue array
            row = 0 #row indicator
            for j in element: #j is each element within each sub-array
                c1 = sheet.cell(row=row+1,column=col+1) #cell location - no zero indexing in Excel
                c1.value = np.float64(j) #affix value to cell location
                row+=1
            col+=1
        wb.save(title) #Save the workbook
        wb.close() #Close the excel document
        # wb.close()
        # # Convert to pdf and export
        # excel = client.Dispatch("Excel.Application",pythoncom.CoInitialize()) #Open excel program on windows
        # path =  os.getcwd().replace('\'','\\') + '\\' #Format the path
        # # Read Excel File
        # sheets = excel.Workbooks.Open(path+title.replace(".xlsx", "")) #Open the excel document to be converted
        # work_sheets = sheets.Worksheets[0] #Set the active sheet
        
        # # Convert into PDF File
        # work_sheets.ExportAsFixedFormat(0, path+title.replace(".xlsx", ""))
        # sheets.Close() #Close the excel document

    def interest_calculator(self, col):
        # fields taken from form
            # short_term =  request.POST["short_term"] #short_term
            # long_term =  request.POST["long_term"] #long_term
            start_date =  self.valuation_date #start_date
            end_date =  self.maturity_date #start_date
            # if col < len(self.inception_trading_days_list):
            #     end_date_string =  self.inception_trading_days_list[col-1] #end_date
            # else:
            #    end_date_string =  self.inception_trading_days_list[-1] #end_date 
            # end_date =  datetime.strptime(end_date_string, '%Y-%m-%d').date() #end_date #end_date
            start_date_string =  start_date.strftime('%Y-%m-%d') #start_date
            end_date_string =  end_date.strftime('%Y-%m-%d') #start_date

            time_interval = end_date - start_date
            time_to_event = int((datetime.now().date() - end_date).days  * (1/365.25))
            # interval_days = int(time_interval.years) #trading days in interval
            interval_years = self.num_years #number of years to maturity #trading days in interval
            # interval_years = float(time_interval.days * (1/365.25)) #number of years to maturity #trading days in interval
            print("interval_years", interval_years, type(interval_years))
            # Run Code
            interest_rate_data = InterestCalculator(start_date, end_date, start_date_string, end_date_string, interval_years).get_interest_rates()

            return interest_rate_data
    def note_values_calculator(self):
        
        present_value_list = []
        for j in range (0, len(self.trading_days_list)): #Iterate over cols
            col= j-1 #intialize cols variable
            self.note_vals_list[col][0] = col+1
            # print("j%self.interest_compounds_nodes::::", j, "%", self.interest_compounds_nodes, "=", j%self.interest_compounds_nodes, )
            accrued_interest_value = self.note_val
            accrued_cash_value = 0
            
            if j == 0: #Check if col equals zero
                if self.accrual_frequency == 'Daily':  #Check if accrual frequency is daily
                    self.note_vals_list[col][1] = round(self.note_val + self.note_val*self.interest_per_accrual, 3) #Add the accrued interest
                    self.note_vals_list[col][2] = round(self.note_val*self.cash_interest_per_accrual, 3) #Add the cash interest
                else:
                    # interest_per_trading_day = self.note_val * (self.interest_per_accrual) / (len(self.trading_days_list)/self.num_years)
                    interest_per_trading_day = self.note_val * (self.interest_per_accrual) / (252)
                    # Special Term
                    # initial_interest_term = (25195 + 107264) /(len(self.trading_days_list)/self.num_years/12)
                    self.note_vals_list[col][1] = self.note_val
                    # self.note_vals_list[col][1] = round(self.note_val+interest_per_trading_day, 3)
                    self.note_vals_list[col][2] = 0
            # Special Clause
            # elif j == 1:
            #     self.note_vals_list[col][1] = self.note_vals_list[col-1][1] + interest_per_trading_day-1620.83
            #     self.note_vals_list[col][2] = accrued_cash_value + self.note_vals_list[col-1][1]*self.cash_interest_per_accrual
            else:
                if self.interest_case == 2:
          
                    
                    interest_per_trading_day = self.note_vals_list[col-1][1] * incremental_rf_rate
                    if j in self.accrual_indices:
                        incremental_rf_rate = self.interest_calculator(col)
                        print("PRESENT VALUE CALC", "{}/(1+{}+{})**{}".format(self.note_vals_list[col][1], incremental_rf_rate, self.credit_spread, j/252))
                        present_value_list.append((self.note_vals_list[col][1]/((1+incremental_rf_rate+self.credit_spread)**(j/252))))
                        # Calculate and add interest if date matches accrual indices
                        self.note_vals_list[col][1] = self.note_vals_list[col-1][1] + interest_per_trading_day
                        self.note_vals_list[col][2] = accrued_cash_value + self.note_vals_list[col-1][1]*self.cash_interest_per_accrual
                    else:
                        # Copy previous nodes
                        self.note_vals_list[col][1] = self.note_vals_list[col-1][1]
                        self.note_vals_list[col][2] = accrued_cash_value
                else:
                    if j%252 == 0:
                        incremental_rf_rate = self.interest_calculator(col)
                        print("PRESENT VALUE CALC", "{}/(1+{}+{})**{}".format(self.note_vals_list[col][1], incremental_rf_rate, self.credit_spread, j/252))
                        present_value_list.append((self.note_vals_list[col][1]/((1+incremental_rf_rate+self.credit_spread)**(j/252))))
                    if col%252 == 0: #Check if 
                    # if j < (len(self.trading_days_list)/self.num_years/12):
                    #     # accrued_interest_value = self.note_vals_list[col][1] = round(accrued_interest_value + accrued_interest_value*(self.interest_per_accrual) + 25195 + 107264, 3)
                    #     # accrued_cash_value = self.note_vals_list[col][2] = round(accrued_cash_value + accrued_interest_value*self.cash_interest_per_accrual, 3)
                    #     self.note_vals_list[col][1] = round(self.note_val+initial_interest_term, 3)
                    #     self.note_vals_list[col][2] = round(accrued_cash_value + self.note_vals_list[col-1][1]*self.cash_interest_per_accrual, 3)
                        
                        interest_per_trading_day = self.note_vals_list[col-1][1] * (self.interest_per_accrual) / (252)
                        # if col/252 == 2:
                        #     # accrued_interest_value = self.note_vals_list[col][1] = round(accrued_interest_value + accrued_interest_value*(self.interest_per_accrual) + 25195 + 107264, 3)
                        #     # accrued_cash_value = self.note_vals_list[col][2] = round(accrued_cash_value + accrued_interest_value*self.cash_interest_per_accrual, 3)
                        #     # interest_per_trading_day = self.note_vals_list[col-1][1] * (self.interest_per_accrual) / (252)
                        #     # print("Interest compounds case2",  col, interest_per_trading_day)
                        #     # self.note_vals_list[col][1] = round(self.note_vals_list[col-1][1] + interest_per_trading_day, 3)
                        #     # self.note_vals_list[col][2] = round(accrued_cash_value + self.note_vals_list[col-1][1]*self.cash_interest_per_accrual, 3)
                        #     additional_accrued_interest = round(self.note_vals_list[col][1]*.04, 3)
                    # accrued_interest_value = self.note_vals_list[col][1] = round(accrued_interest_value + accrued_interest_value*self.interest_per_accrual, 3)
                    # accrued_cash_value = self.note_vals_list[col][2] = round(accrued_cash_value + accrued_interest_value*self.cash_interest_per_accrual, 3)
                # interest_per_trading_day = self.note_vals_list[col-1][1] * (self.interest_per_accrual) / (252)
                # print("Interest compounds case1", col, interest_per_trading_day)
                
                # accrued_interest_value = self.note_vals_list[col][1] = round(self.note_vals_list[col-1][1] + self.note_vals_list[col-1][1]*self.interest_per_accrual, 3)
                # accrued_cash_value = self.note_vals_list[col][2] = round(self.note_vals_list[col-1][2] + self.note_vals_list[col-1][1]*self.cash_interest_per_accrual, 3)
            # elif j%self.monthly_interval == 0:
            #     self.note_vals_list[col][1] = round(self.note_vals_list[col-1][1] + self.note_vals_list[col-1][1]*self.monthly_interest, 3)
            #     self.note_vals_list[col][2] = round(self.note_vals_list[col-1][2] + self.note_vals_list[col-1][1]*self.monthly_cash_interest, 3)

            # else:
            #     self.note_vals_list[col][1] = round(self.note_vals_list[col-1][1]+interest_per_trading_day, 3)
            #     self.note_vals_list[col][2] = self.note_vals_list[col-1][2]
        print("present_value_list", present_value_list)
        present_value = sum(present_value_list)
        return present_value

    def binomial_valuation(self):
        print ("\nStarting Model...\n")
        # print (self.stockvalue) # stock price array
        #create 2 dim. array to hold note values
        #populate initially with 0s 
        
        #self.note_vals_list = [[0 for i in range(cols)] for j in range(rows)]
        # self.note_vals_list = np.zeros((int(self.steps)+1, int(self.steps)+1), dtype=np.float64)
        conversion_vals_list = np.zeros((int(self.steps), int(self.steps)), dtype=np.float64) #Initialize conversion values array
        solution_list = np.zeros((int(self.steps), int(self.steps)), dtype=np.float64) #Initialize solution values array
        converted_solution_list = np.zeros((int(self.steps), int(self.steps)), dtype=np.float64) #Initialize solution values array
        present_value = self.note_values_calculator() #Initialize straight debt array
        print("PRESENT VALUE", present_value)
        # print("NOTE VALS LIST INITIALIZED", self.note_vals_list)
        #print(note_vals) 
        discount_rate_list = np.zeros((int(self.steps), int(self.steps)), dtype=np.float64) #Initialize discount rates array
        discount_rate_1= self.ann_int2 * self.t_step
        discount_rate_2= self.ann_int1 * self.t_step
        print("DISCOUNT RATES", discount_rate_1, discount_rate_2)
        
        #populate last node (Terminal Node) of note value array with all max note values
        element = -1 #denotes last array, terminal node
        for j in range (0, int(self.steps)+1): #Iterate over rows
            col= j-1 #intialize cols variable
                
            CS = self.note_val / self.ex_price #original conversion shares
            V2 = self.stockvalue[element][col] * CS # calculate V2 - intrinsic value as converted
            
            

            
        
        print ("\nStarting Computations Section...\n")
        
        ###Now, COMPUTE PVs using Backward Induction###
        #start with last (terminal) arrray and work backwards
        # print ("Starting i loop...")

        for i in range (int(self.steps), 0, -1): #start index of len-1, step by -1 & end at 0
            #print ('len(note_vals[i])-1 =', len(note_vals[i])-1)
            col= i-1
            
            #calc PV at n-1, compare to intrinsic val as converted, input max val
            for j in range(1, int(self.steps)+1): #stop @ last element-1 index
                row= j-1
                # if (i == 1 and j==1):
                # print ("At this point, col = ", col, ", and row = ", row)
                ####CALCULATE THE DISCOUNT RATE ARRAY RECURSIVELY####
                #if self.note_vals_list[i][j+1]:
                    #if (discount_rate_list[i][j] == discount_rate_2) and (discount_rate_list[i][j+1] == discount_rate_2):
                        #discount_rate_list[i-1][j] = discount_rate_2
                    #else:
                        #discount_rate_list[i-1][j] = discount_rate_1
                    
                ####END DISCOUNT RATE CALCULATIONS#### 
                


                
                #######################################################
                #######CALCULATE WEIGHTED PV USING CORRECT RATES#######
                ####Call the price key from the note_vals disctionary##
                #print (self.stockvalue)
                #### BEGIN Print calculations ####
                #print ('weighted pv calc vars = ')
                #print ('V1 = (note_vals[i][j]["value"] * self.p1 * (np.exp(-rate1 * self.t_step)) + (note_vals[i][j+1]["value"] * self.p2 * (np.exp(-rate2 * self.t_step))))')
                #print ('V1 = (note_vals[i][j]["value"]( ', note_vals[i][j]["value"], ' )* self.p1( ', self.p1, ') * (np.exp(-rate1( ', -rate1, ' ) * self.t_step( ', self.t_step, ' ))) ( ', (np.exp(-rate1 * self.t_step)), ' ) + (note_vals[i][j+1]["value"] ( ', note_vals[i][j+1]["value"], ' ) * self.p2 ( ', self.p2, ' ) * (np.exp(-rate2 ( ', -rate2, ' ) * self.t_step( ', self.t_step, ' ) ))))( ', (np.exp(-rate2 * self.t_step)), ' )')
                #print ('V1 = ', (self.note_vals_list[i][j] * self.p1 * (np.exp(-rate1 * self.t_step)) + (self.note_vals_list[i][j+1] * self.p2 * (np.exp(-rate2 * self.t_step)))))
                #### END Print calculations ####


                
                
                # print('self.stockvalue[col][j] = ', self.stockvalue[col][j])
                #Check to skip zero values and avoid errors
                
                if self.stockvalue[col][row] > 0:
                    
                    if self.stockvalue[col][row-1]  > 0 and self.stockvalue[col][row-1] < self.trigger: #test jth element of final sub-array
                        # print("267 CS = self.note_val / (self.stockvalue[col-1][row] * self.CF)",self.stockvalue[col-1][row], col, row)
                        CS = self.note_val / (self.stockvalue[col][row-1] * self.CF) # calc new conversion shares
                        
                        #if i>=11:
                            #print ('CS case 1 =', CS)
                    else:
                        CS = self.note_val / self.ex_price #original conversion shares   
                    


                    if self.mandatory_conversion_percent_condition == 'true' and self.stockvalue[col][row] > self.mandatory_conversion_val:
                        # if row == 1 and col == self.steps-1:
                            # print("MANDATORY CONVERSION RUNNING", self.mandatory_conversion_val * self.note_val / self.ex_price)
                        conversion_vals_list[col][row] = self.mandatory_conversion_val * self.note_val / self.ex_price
                        if col == self.steps-1:
                            V1=0
                        else:
                            V1 = (solution_list[col+1][row] * self.p1 * (np.exp(-discount_rate_list[col+1][row] * self.t_step)) + (solution_list[col+1][row+1] * self.p2 * (np.exp(-discount_rate_list[col+1][row+1] * self.t_step))))
                    elif col == self.steps-1:
                        # print("TERMINAL NODE CONVERSION VALUE RUNNING!!!!", self.stockvalue[col][row] * self.ex_price * self.note_val)
                        conversion_vals_list[col][row] = self.stockvalue[col][row] * self.note_val / self.ex_price
                        # print("conversion_vals_list[i][row] = self.stockvalue[col-1][row] * self.ex_price", self.stockvalue[col-1][row], "*", self.ex_price)
                        V1=0
                    else:
                        V1 = (solution_list[col+1][row] * self.p1 * (np.exp(-discount_rate_list[col+1][row] * self.t_step)) + (solution_list[col+1][row+1] * self.p2 * (np.exp(-discount_rate_list[col+1][row+1] * self.t_step))))
                        # print("V1 CALC", col, row, V1)
                        if self.stockvalue[col+1][row] > 0:
                            # conversion_vals_list[row-1][col-1] = self.stockvalue[row-1][i] * self.ex_price * self.note_val
                            conversion_vals_list[col][row] = self.stockvalue[col][row] * self.note_val / self.ex_price
                        # else:
                        #     conversion_vals_list[col][row] = round(self.stockvalue[col][row] * self.note_val / self.ex_price, 5)
                    # print("conversion_vals_list[i][row] = self.stockvalue[col-1][row] * self.ex_price", self.stockvalue[col-1][row], "*", self.ex_price)
 
                        #f i>=11:
                            #print ('CS case 2 =', CS)
                    #if i>=11:
                        #print ('V2 = self.stockvalue[col-1][row] * CS')
                        #print ('V2 = self.stockvalue[col-1][row] ( ', self.stockvalue[col-1][row], ' ) * CS (', CS, ' )')
                    # if col == 0:
                    #     V2 = self.stockvalue[col][row] * CS # calculate V2 - intrinsic value as converted
                    # else:
                    # print("267 V2 = self.stockvalue[col-1][row] * CS",self.stockvalue[col-1][row], col, row)
                else:
                    CS = 0
                    V1=0
                    
                        #print ('CS case 0 =', CS)
                        #print ("####END of 'j' loop####\n")   
                # V2 = self.stockvalue[row][i] * CS # calculate V2 - intrinsic value as converted
                # if len(self.note_vals_list) <= col+self.inception_to_valuation_delta:
                #     V2 = self.note_vals_list[len(self.note_vals_list)-1][1] # calculate V2 - intrinsic value as converted
                # else:
                #     V2 = self.note_vals_list[col+self.inception_to_valuation_delta][1] # calculate V2 - intrinsic value as converted
                V2 = self.note_vals_list[col][1] # calculate V2 - intrinsic value as converted
                # V2 = self.stockvalue[col-1][row] * CS # calculate V2 - intrinsic value as converted
                #if i>=11:
                    #print ('V1 =', V1)
                    #print ('V2 =', V2)
                    #print ('Max = V2', max(V1, V2) == V2)
                    #print ('Max = V1', max(V1, V2) == V1)
                
                #### Pass in Objects with Value and Option keys
                #####Tony Additions#####
                #note_vals[i-1][row] = max(V1, V2)
                ####Reversed if statement order.  Fixed 3 vals broke 2.
                v1 = float("{0:.2f}".format(V1))
                v2 = float("{0:.2f}".format(V2))
                
                # Solution Lattice
                if conversion_vals_list[col][row] > 0:
                    # Condition for mandatory conversion by percentage of a fixed conversion value
                    if self.mandatory_conversion_percent_condition == 'true' and self.stockvalue[col][row] > self.mandatory_conversion_val:
                        solution_list[col][row] = conversion_vals_list[col][row]
                        converted_solution_list[col][row] = conversion_vals_list[col][row] * self.fx_rate
                    elif col == len(conversion_vals_list[col]-1):
                        if conversion_vals_list[col][row] > self.note_vals_list[col+self.inception_to_valuation_delta][1]:
                            solution_list[col][row] = conversion_vals_list[col][row]
                            converted_solution_list[col][row] = conversion_vals_list[col][row] * self.fx_rate
                        else:
                            solution_list[col][row] = self.note_vals_list[col+self.inception_to_valuation_delta][1]
                            converted_solution_list[col][row] = self.note_vals_list[col+self.inception_to_valuation_delta][1] * self.fx_rate
                    else:
                        solution_list[col][row] = max(V1, conversion_vals_list[col][row])
                        converted_solution_list[col][row] = max(V1, conversion_vals_list[col][row]) * self.fx_rate

            
                        
                        # Old code
                        # self.note_vals_list[i-1][row] = v1
                        # End old code
                         
                    # Discount Rate Lattice
                if self.stockvalue[col][row] != 0:
                    if col == self.steps-1: #Check if terminal column
                        # print("LAST COL DISCOUNT RATE CALC!!!!", row, solution_list[col][row], v2, solution_list[col][row] == v2)
                        if (solution_list[col][row] == v2):
                            discount_rate_list[col][row] = discount_rate_2*100
                        else:
                            discount_rate_list[col][row] = discount_rate_1*100
                    elif max(v1,conversion_vals_list[col][row])==conversion_vals_list[col][row]:
                        discount_rate_list[col][row] = discount_rate_1*100
                    elif max(v1,conversion_vals_list[col][row])==v1:
                        # print("BLENDED DISCOUNT RATE RUNNING", col, row, v1)
                        discount_rate_list[col][row] = (discount_rate_list[col+1][row]*self.p1+discount_rate_list[col+1][row+1]*self.p2)
                        # End From excel
                        # if col == self.steps-2: #Check if terminal column
                        #     print("LAST COL DISCOUNT RATE CALC!!!!", row, v1, v2)
                        # if max(v1, conversion_vals_list[col][row]) == conversion_vals_list[col][row]:
                        #     discount_rate_list[col][row] = round(discount_rate_2*100, 5)
                        #     # Old Code   
                        #     # self.note_vals_list[i-1][row] = v2
                        #     # end old code
                        #     # if i == 10:
                        # else:
                        #     if (discount_rate_list[col+1][row] == round(discount_rate_2*100, 5)) and (discount_rate_list[col+1][row+1] == round(discount_rate_2*100, 5)):
                        #         discount_rate_list[col][row] = round(discount_rate_2*100, 5)
                        #     else:
                        #         discount_rate_list[col][row] = round(discount_rate_1*100, 5)
                    
                        
                    #print ("####END of 'j' loop####\n") 
                    
                            
                # if (i-1) == 0:
                #     print ("####END OF PROGRAM####")
                #     break
        ######END OPTION TEST INTEGRATION ######
        
        #self.generate_excel_lattice(note_vals)
        #######Set Value 1
        # print('NOTE VALS LIST', self.note_vals_list)
        fair_val1 = self.note_vals_list[1][0]
        #####Calculate the converted note value Per $100 of principal#####
        fair_val2 = self.note_vals_list[1][0] / (self.note_val/100)
        
        # Set titles and Export all tables as excel and pdf
        title = "lattice-model-note-values.xlsx"
        pdf_note_val_title = "Note Values"
        self.generate_excel_lattice(self.note_vals_list, title)
        encodedNoteVals = json.dumps(self.note_vals_list, cls=NumpyArrayEncoder)  # use dump() to write
        truncated_note_vals = self.truncate(self.note_vals_list)
        json_truncated_note_vals = json.dumps(truncated_note_vals)

        conversion_title = "lattice-model-conversion-values.xlsx"
        rounded_conversion_vals = np.around(conversion_vals_list, 2)
        self.generate_excel_lattice(rounded_conversion_vals, conversion_title)
        encodedConversionVals = json.dumps(rounded_conversion_vals, cls=NumpyArrayEncoder)  # use dump() to write
        pdf_conv_val_title = 'Conversion Values'
        truncated_conversion_vals = self.truncate(rounded_conversion_vals)
        json_truncated_conversion_vals = json.dumps(truncated_conversion_vals)

        pdf_straight_debt_title = "Straight Debt"
        rates_title = "lattice-model-discount-rates.xlsx"
        rounded_discount_rate = np.around(discount_rate_list, 2)
        self.generate_excel_lattice(rounded_discount_rate, rates_title)
        encodedStraigtDebt = json.dumps(rounded_discount_rate, cls=NumpyArrayEncoder)  
        truncated_debt_vals = self.truncate(rounded_discount_rate)
        json_truncated_debt_vals = json.dumps(truncated_debt_vals)

        pdf_solution_title = "Solution Values"
        solution_title = "lattice-model-solution.xlsx"
        rounded_solution_list = np.around(solution_list, 2)
        self.generate_excel_lattice(rounded_solution_list, solution_title)
        encodedSolutionVals = json.dumps(rounded_solution_list, cls=NumpyArrayEncoder)  # use dump() to write
        truncated_solution_vals = self.truncate(rounded_solution_list)
        json_truncated_solution_vals = json.dumps(truncated_solution_vals)

        pdf_stock_vals_title = "Stock Values"
        rounded_stock_vals = np.around(self.stockvalue, 2)
        stock_val_title = "lattice-model-stock-values.xlsx"
        self.generate_excel_lattice(rounded_stock_vals, stock_val_title) #call method to print results to Excel
        encodedStockVals = json.dumps(rounded_stock_vals, cls=NumpyArrayEncoder)  # use dump() to write
        truncated_stock_vals = self.truncate(rounded_stock_vals)
        json_truncated_stock_vals = json.dumps(truncated_stock_vals)
        
        self.create_pdf(pdf_stock_vals_title, truncated_stock_vals, pdf_note_val_title, truncated_note_vals, pdf_conv_val_title, truncated_conversion_vals, pdf_straight_debt_title, truncated_debt_vals, pdf_solution_title, truncated_solution_vals, present_value)
        
        val_obj = Valuation.objects.get(id=self.valuation_id, user=self.user)
         # Save Binomial Lattice to Database
        # print("ENCODED SOLUTION VALS!!!!", encodedSolutionVals)
        binomialLattice = BinomialLattice(
            stock_values=encodedStockVals,
            solution_values=encodedSolutionVals,
            note_values=encodedNoteVals,
            conversion_values=encodedConversionVals,
            straight_debt_values = encodedStraigtDebt,
            truncated_stock_values = json_truncated_stock_vals,
            truncated_solution_values = json_truncated_solution_vals,
            truncated_note_values = json_truncated_note_vals,
            truncated_conversion_values = json_truncated_conversion_vals,
            truncated_straight_debt_values = json_truncated_debt_vals,
            valuation=val_obj,
            user=self.user)
        binomialLattice.save()
        print("BINOMIALLATTICE SAVED", binomialLattice.id)
        #####Return final values: Note + Option & Converted Note#####
        #############################################################
        #print(self.note_vals_list)
        print ('Fair Value 1: ', fair_val1)
        print ('Fair Value 2: ', fair_val2)
        return fair_val1
    #quit()

        
