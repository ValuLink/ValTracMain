from .models import BinomialLattice
from accounts.models import Agent
from rest_framework import viewsets, permissions, status, filters
# from rest_framework.response import Response
# from rest_framework.views import APIView
from .serializers import BinomialLatticeSerializer
# from rest_framework.exceptions import APIException
# from django.conf import settings
# from django.http import Http404
# import stripe


# BinomialLattice Viewset
class BinomialLatticeViewSet(viewsets.ModelViewSet):
    queryset = BinomialLattice.objects.all()
    permission_classes = [
        permissions.IsAuthenticated
        #permissions.AllowAny
    ]
    serializer_class = BinomialLatticeSerializer
    filter_backends = [filters.OrderingFilter]
    ordering_fields = ['id',]
    ordering = ['-id',]

    def get_queryset(self):
        return self.request.user.BinomialLattice.all()

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

# AgentBinomialLattice Viewset
class AgentBinomialLatticeViewSet(viewsets.ModelViewSet):
    queryset = BinomialLattice.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = BinomialLatticeSerializer
    filter_backends = [filters.OrderingFilter]
    ordering_fields = ['id']
    ordering = ['-id']

    def get_queryset(self):
        user = self.request.user
        if hasattr(user, 'agent') and user.agent.is_agent:
            return BinomialLattice.objects.filter(agent=user.agent)
        return BinomialLattice.objects.none()

    def perform_create(self, serializer):
        user = self.request.user
        if hasattr(user, 'agent') and user.agent.is_agent:
            serializer.save(agent=user.agent, user=user)
        else:
            serializer.save(user=user)

