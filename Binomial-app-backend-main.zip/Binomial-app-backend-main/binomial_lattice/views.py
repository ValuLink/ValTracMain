import imp
from django.shortcuts import render

import openpyxl
from .BinomialModel12 import Binomial
from .OASCalculator import OASCalculator
# from .FredAPI import get_interest_rates, get_stock_prices
# import time
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, renderer_classes
from rest_framework.renderers import JSONRenderer
from datetime import datetime, date
import math

import pandas as pd
from pandas_market_calendars import get_calendar

# from forex_python.converter import CurrencyRates #Currency rate conversion library

from .VolatilityCalculator import VolatilityCalculator
# Create your views here.
# Create your views here.

def format_value(value):
    return f'${value:,.2f}'
@api_view(('POST', ))
@renderer_classes((JSONRenderer, ))
def create_binomial_lattice(request):
    if request.method == "POST":
        # Check if user is logged in
        if request.user.is_authenticated:
            # wb1 = openpyxl.load_workbook('Amyris_Binomial-ConvertibleNote-Inputs_3-2-20_v3.0(rc).xlsx' ,data_only=True)
            # df1 = wb1['DATA']
            #obtain data for simulation by col & row

            # fields taken from form
            valuation_id = request.POST["valuation_id"] #company_name
            company_name = request.POST["company_name"] #company_name
            instrument_name = request.POST["instrument_name"] #instrument_name
            public_company_ticker = request.POST["public_company_ticker"] #public_company_ticker
            currency_one = request.POST["currency_one"] #currency_one
            currency_two = request.POST["currency_two"] #currency_two
            valuation_date =  datetime.strptime(request.POST["valuation_date"], '%Y-%m-%d').date() #valuation_date
            inception_date =  datetime.strptime(request.POST["inception_date"], '%Y-%m-%d').date() #inception_date
            maturity_date =  datetime.strptime(request.POST["maturity_date"], '%Y-%m-%d').date() #maturity_date
            event_date_1 =  datetime.strptime(request.POST["maturity_date"], '%Y-%m-%d').date() # first event_date
            event_date_2 =  datetime.strptime(request.POST["maturity_date"], '%Y-%m-%d').date() # second event_date

            

            

            # Define the trading calendar you're interested in (e.g. NYSE)
            trading_calendar = get_calendar('NYSE')

            # Get the trading days within the time period using the trading calendar
            trading_days = trading_calendar.schedule(start_date=valuation_date, end_date=maturity_date)
            # print("trading Days!!!!", trading_days)
            first_trading_day = trading_days.index[0].date()


            

            

            # Currency Converter code
            # if currency_one != "" and currency_two != "":
            #     # fx_rate = c.get_rate(currency_one, currency_two, first_trading_day)
            #     fx_rate = get_exchange_rate(currency_one, currency_two, first_trading_day)
            #     print(f'Exchange rate on {first_trading_day}: 1 {currency_one} = {fx_rate:.4f} {currency_two}')
            # else:
            #     fx_rate = 1
            if request.POST["fx_rate"] != '':
                fx_rate = float(request.POST["fx_rate"])
            else:
                fx_rate = 1
            
            
            # initial_proceeds = float(request.POST["offering_proceeds"]) #offering_proceeds
            if request.POST["credit_spread"] == '':
                credit_spread = 0
            else:
                credit_spread = float(request.POST["credit_spread"]) #total initial prinicpal amount
            initial_note_value = float(request.POST["stated_principal"]) #total initial prinicpal amount
            nominal_interest_rate = float(request.POST["nominal_interest_rate"]) #ananual market rate of interest
            accrual_frequency = request.POST["accrual_frequency"]#accrual_frequency
            if request.POST["interest_rate_accrual"] != '':
                interest_rate_accrual = float(request.POST["interest_rate_accrual"]) #interest_rate_accrual
            if request.POST["interest_rate_cash_payment"] != '':
                interest_rate_cash_payment = float(request.POST["interest_rate_cash_payment"]) #interest_rate_cash_payment
            # dividend_yield = float(request.POST["dividend_yield"]) #dividend_yield
            initial_conv_price = float(request.POST["initial_conversion_price"]) #conversion price
            # fx_rate = float(request.POST["usd_to_cad_fx_rate"]) #fx_rate
            risk_free_rate = float(request.POST["risk_free_rate"]) #annual risk-free interest rate
            # ann_vol = float(request.POST["volatility"])/100 #annual volatility
            # ann_vol = 1 #annual volatility
            stock_price = float(request.POST["stock_price"]) #starting stock price
            mandatory_conversion_percent_condition = request.POST["mandatory_conversion_percent_condition"] #Bool condition of mandatory conversion at a percentage threshold
            if request.POST["mandatory_conversion_percentage"] != '':
                mandatory_conversion_percentage = float(request.POST["mandatory_conversion_percentage"]) #Trigger percentage for mandatory conversion percent condition
            else:
                mandatory_conversion_percentage = 0
            if request.POST["fixed_conversion_price"] != '':
                fixed_conversion_price = float(request.POST["fixed_conversion_price"]) #fixed_conversion_price for mandatory conversion percent condition
            else:
                fixed_conversion_price = 0
            
            accrued_note_value = initial_note_value # principal + accrued interest
            

            new_conv_price = initial_conv_price #conversion price
            initial_conv_shares = int(initial_note_value/initial_conv_price) #conversion shares
            new_conv_shares = int(accrued_note_value/new_conv_price) #conversion shares
            # Calculated fields
            trigger = float(request.POST["initial_conversion_price"])  #trigger price for new conv. shares
            maturity_time = maturity_date - valuation_date
            # event_date_1 = maturity_date - valuation_date
            # event_date_2 = maturity_date - inception_date
            num_years = float(maturity_time.days * (1/365.25)) #number of years to maturity
            num_days1 = int(maturity_time.days) #calendar days to maturity
            # num_days2 = int(maturity_time.days * (5/7)) #trading days to maturity = steps in lattice
            # inception_num_years = int(event_date_2.days * (1/365.25)) #number of years to maturity
            # inception_num_days1 = int(event_date_2.days) #calendar days to maturity
            # inception_num_days2 = int(event_date_2.days * (5/7)) #trading days to maturity = steps in lattice
            # time_step_days = int(num_days1 / number_of_steps)
            # # print("TIME STEP DAYS!!!!", num_days1, "/", number_of_steps, "=", time_step_days)
            # time_step_years = int(num_years / number_of_steps)
            # Define the trading calendar you're interested in (e.g. NYSE)
            trading_calendar = get_calendar('NYSE')

            # Get the trading days within the time period using the trading calendar
            inception_trading_days = trading_calendar.schedule(start_date=inception_date, end_date=maturity_date)
            trading_days = trading_calendar.schedule(start_date=valuation_date, end_date=maturity_date)

            # Convert the dates to a list of strings
            trading_days_list = [str(date.date()) for date in trading_days.index]
            inception_trading_days_list = [str(date.date()) for date in inception_trading_days.index]
            inception_to_valuation_delta = len(inception_trading_days_list) - len(trading_days_list)
            print("INC")

            if request.POST["number_of_steps"] == '':
                number_of_steps = len(trading_days)
            else:
                number_of_steps = int(request.POST["number_of_steps"]) #number_of_steps
            if accrual_frequency == 'Daily':
                interest_compounds_nodes = 1
                interest_per_accrual = interest_rate_accrual/36000
                cash_interest_per_accrual = interest_rate_cash_payment/36000
            elif accrual_frequency == 'Monthly':
                interest_compounds_nodes = math.floor(len(trading_days)/(num_years*12))
                interest_per_accrual = interest_rate_accrual/1200
                cash_interest_per_accrual = interest_rate_cash_payment/1200
            elif accrual_frequency == 'Quarterly':
                interest_compounds_nodes = math.floor(len(trading_days)/(num_years*4))
                interest_per_accrual = interest_rate_accrual/400
                cash_interest_per_accrual = interest_rate_cash_payment/400
                
            elif accrual_frequency == 'Semi-Annually':
                interest_compounds_nodes = math.floor(len(trading_days)/(num_years*2))
                interest_per_accrual = interest_rate_accrual/200
                cash_interest_per_accrual = interest_rate_cash_payment/200
            elif accrual_frequency == 'Annually':
                interest_compounds_nodes = math.floor(len(trading_days)/num_years)
                interest_per_accrual = interest_rate_accrual/100
                cash_interest_per_accrual = interest_rate_cash_payment/100
            else:
                interest_compounds_nodes = 1
                interest_per_accrual = 0
                cash_interest_per_accrual = 0

            monthly_interest = interest_rate_accrual/1200
            monthly_cash_interest = interest_rate_cash_payment/1200

            

            monthly_interval = len(trading_days)/(num_years * 12)
            # print("Interest compounds nodes!!!!", interest_compounds_days, "/", time_step_days, "=", interest_compounds_nodes)
            # print("\nProcessing Row: " + str(df1["A" + str(row)].value))
            # print(num_days2)
            # print('trading_days_list:', trading_days_list)
            # print('initial_note_value:', initial_note_value)
            # print('initial_conv_price:', initial_conv_price)
            # print('initial_conv_shares:', initial_conv_shares)
            # print('stock_price:', stock_price)
            # print('trigger:', trigger)
            print('num_years:', num_years)
            # print('num_days1:', num_days1)
            # print('num_days2:', num_days2)
            # print('number_of_steps:', number_of_steps)
            # print('ann_vol:', ann_vol)
            # print('risk_free_rate:', risk_free_rate)
            # print('nominal_interest_rate:', nominal_interest_rate)
            #instantiate 'binomial' object and pass in arguments(data)
            #val1 = PV of note
            # Get fred api interest rates
            # interest_rate_data = get_interest_rates()
            # stock_prices_data = get_stock_prices()
            current_date = date.today()
            days_after_close = int((current_date - maturity_date).days * (252/365.25)) # trading days after close
            date_time = current_date.strftime("%Y-%m-%d")
            current_day = pd.Period(date_time, freq='D')
            days_of_year = current_day.day_of_year
            print("days_of_year!!!!", days_of_year)
            num_trading_days = len(trading_days_list)
            #volatility_time_period
            if request.POST["volatility_time_period"] == '':
                volatility_time_period = 0
            else:
                volatility_time_period = float(request.POST["volatility_time_period"]) #total initial prinicpal amount
            # volatility case
            # 1. automatic calculation: valuation date to maturity date
            # 2. Set volatility manually
            # 3. Set time manually from input
            # 4. Event specific calculation:  valuation date to event date
            if request.POST["volatility_case"] == '':
                volatility_case = 1
            else:
                volatility_case = int(request.POST["volatility_case"]) #total initial prinicpal amount
            
            if volatility_case == 2:
                volatility = float(request.POST["volatility"]) #annual volatility
            elif volatility_case == 3:
                volatility_date_1 =  datetime.strptime(request.POST["volatility_date_1"], '%Y-%m-%d').date() #volatility_date
                volatility_date_2 =  datetime.strptime(request.POST["volatility_date_2"], '%Y-%m-%d').date() #volatility_date
                print("VOLATILITY CASE 3 RUNNING")
                # Run Code
                volatility = VolatilityCalculator(public_company_ticker, volatility_date_1, volatility_date_2, num_trading_days, days_of_year, request.user).calculate_volatility()
            elif volatility_case == 4:
                # Run Code
                volatility = VolatilityCalculator(public_company_ticker, valuation_date, event_date_1, num_trading_days, days_of_year, request.user).calculate_volatility()
            else:
                # Run Code
                volatility = VolatilityCalculator(public_company_ticker, valuation_date, maturity_date, num_trading_days, days_of_year, request.user).calculate_volatility()
                # print('VOLATILITY!!!!', volatility)
            # interest compounds case
            # 1. automatic calculation: valuation date to maturity date
            # 2. Set dates interest accrues manually
            if request.POST["interest_case"] == '':
                interest_case = 1
            else:
                interest_case = int(request.POST["interest_case"]) #total initial prinicpal amount
            
            if interest_case == 2:
                accrual_date_one = datetime.strptime(request.POST["accrual_date_one"], '%Y-%m-%d').date()  #annual accrual_date_one
                accrual_index_one = ((accrual_date_one - valuation_date) * (252/365.25)).days#index of accrual date one
                accrual_date_two = datetime.strptime(request.POST["accrual_date_two"], '%Y-%m-%d').date()  #annual accrual_date_two
                accrual_index_two = ((accrual_date_two - valuation_date) * (252/365.25)).days#index of accrual date two
                accrual_indices = [accrual_index_one, accrual_index_two]
                print("accrual_index_one:accrual_index_two", accrual_index_one, ":", accrual_index_two)
            else:
                accrual_date_one = datetime.strptime(request.POST["accrual_date_one"], '%Y-%m-%d').date()  #annual accrual_date_one #annual accrual_date_one
                # (accrual_date_one-ValuationDate)/DaysPerYear
                days_to_accrual = accrual_date_one-valuation_date
                accrual_adjustment = days_to_accrual/365.25
                accrual_index_one = (days_to_accrual * (252/365.25)).days#index of accrual date one
                accrual_date_two = '' #annual accrual_date_two
                accrual_index_two = '' #annual accrual_index_two

            # oas = OASCalculator().get()
            # Run Code
            val1 = Binomial (initial_note_value, initial_conv_price, initial_conv_shares, stock_price, trigger, num_years, num_days1, number_of_steps, volatility, risk_free_rate, nominal_interest_rate, interest_compounds_nodes, interest_per_accrual, cash_interest_per_accrual, accrual_frequency, request.user, valuation_id, company_name, mandatory_conversion_percent_condition, mandatory_conversion_percentage, fixed_conversion_price, trading_days_list, fx_rate, monthly_interval, monthly_interest, monthly_cash_interest, inception_trading_days_list, inception_to_valuation_delta, valuation_date, maturity_date, credit_spread, interest_case, accrual_indices).calculate()
            
            print ("Value per $100 of Face Value = ", format_value(val1))
            # End Run Code

            #####Print results back to spreadsheet#####
            # df1["W" + str(row)].value = val1
            
            # wb1.save("Amyris_Binomial-ConvertibleNote-RESULTS_2-25-20.xlsx")
            return Response(company_name, status=status.HTTP_200_OK)
        else:
            # Return Auth error if user is not logged in
            return Response({"error": "Auth Error"},
                            status=status.HTTP_400_BAD_REQUEST)
    else:
        # Return Error if invalid method
        return Response({"error": "Method not allowed"},
                        status=status.HTTP_400_BAD_REQUEST)
