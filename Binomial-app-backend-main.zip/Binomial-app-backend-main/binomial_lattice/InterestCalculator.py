# from fredapi import Fred
from full_fred.fred import Fred
from valtrak.settings import FRED_API_KEY, ALPHA_VANTAGE_API_KEY

from alpha_vantage.timeseries import TimeSeries
import requests
import numpy as np
import openpyxl
import json
from json import JSONEncoder
# Pdf conversion imports
from win32com import client
import pythoncom
import os
import pandas as pd
from datetime import datetime

from interest_rates_calculator.models import InterestRates
# from valuation_creator.models import Valuation

class InterestCalculator:
    def __init__(self, start_date, end_date, start_date_string, end_date_string, interval_years):
        self.start_date = start_date #principal per note
        self.end_date = end_date #principal per note
        self.start_date_string = start_date_string #principal per note
        self.end_date_string = end_date_string #principal per note
        self.interval_years = interval_years #interval_years
        # self.short_term = short_term #time_to_event
        # self.long_term = long_term #time_to_event

    def get_interest_rates(self):
        # fred = Fred(FRED_API_KEY)
        # fred = Fred(api_key=FRED_API_KEY)
        fred = Fred('interest_rates_calculator/fredkey.txt')
        fred.get_api_key_file()

        # print("FRED API INIT", fred)
        
        # print("get_interest_rates Running!!!! start_date = {} end_date = {} interval_years = {} start_date_string = {} end_date_string={}".format(self.start_date, self.end_date, self.interval_years, self.start_date_string, self.end_date_string))
        # if self.short_term != 'None':
        if self.interval_years == 5:
            long_data = fred.get_series_df('DGS5')
            long_term_num = 5
            short_term_num = 0
            long_term_title = "DGS5"
        elif self.interval_years == 3:
            long_data = fred.get_series_df('DGS3')
            long_term_num = 3
            short_term_num = 0
            long_term_title = "DGS3"
        elif self.interval_years == 2:
            long_data = fred.get_series_df('DGS2')
            long_term_num = 2
            short_term_num = 0
            long_term_title = "DGS2"
        elif self.interval_years == 1:
            long_data = fred.get_series_df('DGS1')
            long_term_num = 1
            short_term_num = 0
            long_term_title = "DGS1"
        elif self.interval_years == .5:
            long_data = fred.get_series_df('DGS6MO')
            long_term_num = .5
            short_term_num = 0
            long_term_title = "DGS6MO"
        elif self.interval_years == .25:
            long_data = fred.get_series_df('DGS3MO')
            long_term_num = .25
            short_term_num = 0
            long_term_title = "DGS3MO"
        elif self.interval_years == .08:
            long_data = fred.get_series_df('DGS1MO')
            long_term_num = .25/3
            short_term_num = 0
            long_term_title = "DGS1MO"
        elif self.interval_years < 5 and self.interval_years > 3:
            long_data = fred.get_series_df('DGS5')
            long_term_num = 5
            short_data = fred.get_series_df('DGS3')
            short_term_num = 3
            long_term_title = "DGS5"
            short_term_title = "DGS3"
        elif self.interval_years < 3 and self.interval_years > 2:
            long_data = fred.get_series_df('DGS3')
            long_term_num = 3
            short_data = fred.get_series_df('DGS2')
            short_term_num = 2
            long_term_title = "DGS3"
            short_term_title = "DGS2"
        elif self.interval_years < 2 and self.interval_years > 1:
            long_data = fred.get_series_df('DGS2')
            long_term_num = 2
            short_data = fred.get_series_df('DGS1')
            short_term_num = 1
            long_term_title = "DGS2"
            short_term_title = "DGS1"
        elif self.interval_years < 1 and self.interval_years > .5:
            long_data = fred.get_series_df('DGS1')
            long_term_num = 1
            short_data = fred.get_series_df('DGS6MO')
            short_term_num = .5
            long_term_title = "DGS1"
            short_term_title = "DGS6MO"
        elif self.interval_years < .5 and self.interval_years > .25:
            long_data = fred.get_series_df('DGS6MO')
            long_term_num = 1
            short_data = fred.get_series_df('DGS3MO')
            short_term_num = .5
            long_term_title = "DGS6MO"
            short_term_title = "DGS3MO"
        elif self.interval_years < .25 and self.interval_years > .08:
            long_data = fred.get_series_df('DGS3MO')
            long_term_num = 1
            short_data = fred.get_series_df('DGS1MO')
            short_term_num = .5
            long_term_title = "DGS3MO"
            short_term_title = "DGS1MO"
        # print("long_data['date']", long_data['date'])
        start_date = pd.to_datetime(self.start_date_string)
        if short_term_num != 0:
            # shortRate = short_data.loc[short_data['date'] == self.start_date_string].iat[0, 3]
            # Filter the dataframe based on the date
            
            # filtered_short_data = short_data[datetime.strptime(short_data['date'], '%Y-%m-%d').date() <= self.start_date]
            # Convert the 'date' column to datetime if it's not already in that format
            short_data['date'] = pd.to_datetime(short_data['date'])
            # Filter the dataframe based on the date
            filtered_short_data = short_data[short_data['date'] <= start_date]
            # Print the column names of the filtered dataframe
            print("SHORT COLUMNS", filtered_short_data.columns)
            # Get the last row from the filtered dataframe
            shortRate = filtered_short_data.iloc[-1]['value']
            short_title = 'short_interest_rates.xlsx'
            self.generate_excel_interest_rates(short_data, short_title, short_term_title)
            print("SHORT RATE RUNNING", shortRate, short_term_num)
        else:
            shortRate = 0

        # longRate = long_data.loc[long_data['date'] == self.start_date_string].iat[0, 3]
        # Filter the dataframe based on the date
        # filtered_long_data = long_data[datetime.strptime(long_data['date'], '%Y-%m-%d').date() <= self.start_date]
        # Filter the dataframe based on the date
        # Convert the 'date' column to datetime
        long_data['date'] = pd.to_datetime(long_data['date'])
        filtered_long_data = long_data[long_data['date'] <= start_date]
        # Print the column names of the filtered dataframe
        print("LONG COLUMNS", filtered_long_data.columns)
        # Get the last row from the filtered dataframe
        longRate = filtered_long_data.iloc[-1]['value']
        long_title = 'long_interest_rates.xlsx'
        self.generate_excel_interest_rates(long_data, long_title, long_term_title)
        print("LONG RATE", longRate, long_term_num)
        # print("START DATE", self.start_date_string)

        # else:
        #     shortRate = 0
        #     short_term_num = 0
        
        # if self.long_term == "5 years":
        #     long_data = fred.get_series_df('DGS5')
        #     long_term_num = 5
        # elif self.long_term == "3 years":
        #     long_data = fred.get_series_df('DGS3')
        #     long_term_num = 3
        # elif self.long_term == "2 years":
        #     long_data = fred.get_series_df('DGS2')
        #     long_term_num = 2
        # elif self.long_term == "1 year":
        #     long_data = fred.get_series_df('DGS1')
        #     long_term_num = 1
        # elif self.long_term == "6 months":
        #     long_data = fred.get_series_df('DGS6MO')
        #     long_term_num = .5
        # elif self.long_term == "3 months":
        #     long_data = fred.get_series_df('DGS3MO')
        #     long_term_num = .25
        # elif self.long_term == "1 month":
        #     long_data = fred.get_series_df('DGS1MO')
        #     long_term_num = .25/3
        # print("oneYearConstantMaturity", oneYearConstantMaturity)
        # print("threeYearConstantMaturity", threeYearConstantMaturity)
        # print("fiveYearConstantMaturity", fiveYearConstantMaturity)
        # shortRate = threeYearConstantMaturity.loc[threeYearConstantMaturity['date'] == self.start_date]
        # longRate = fiveYearConstantMaturity.loc[fiveYearConstantMaturity['date'] == self.start_date]
        # print("LONG RATE RUNNING", longRate)
        # print("shortRate", short_data.loc[short_data['date'] == self.start_date_string])
        # print("longRate", long_data.loc[long_data['date'] == self.start_date_string])
        return self.interim_rate(shortRate, longRate, self.interval_years, short_term_num, long_term_num)

    def generate_excel_lattice(self, vals, title):
        #print binomial tree results to Excel
        #transpose arrays
        # Create titles for documents
        titles = ['Risk Free Spread', 'Risk Free Time Spread', 'Incremental Period', 'Incremental Time Percent', 'Incremental Yield', 'Incremental Risk Free Rate']

         # Save to Database
        interest_rates = InterestRates(
            start_date=self.start_date,
            end_date=self.end_date,
            short_term=self.short_term,
            long_term=self.long_term,
            risk_free_spread=vals[0],
            risk_free_time_spread=vals[1],
            incremental_period=vals[2],
            incremental_time_percent=vals[3],
            incremental_yield=vals[4],
            incremental_risk_free_rate=vals[5],
            # valuation=val_obj,
            user=self.user)
        interest_rates.save()
        # print("interest_rates SAVED", interest_rates.id)
        # Save as excel table
        wb = openpyxl.Workbook()
        sheet = wb.active

        for i in range(0, len(titles)): #i is each element within each sub-array
            c1 = sheet.cell(row=1,column=i+1) #cell location - no zero indexing in Excel
            c1.value = titles[i] #affix value to cell location
            c1 = sheet.cell(row=2,column=i+1) #cell location - no zero indexing in Excel
            c1.value = vals[i] #affix value to cell location
        wb.save(title) 
        wb.close()
        # Convert to pdf and export
        excel = client.Dispatch("Excel.Application",pythoncom.CoInitialize())
        path =  os.getcwd().replace('\'','\\') + '\\'
        # Read Excel File
        sheets = excel.Workbooks.Open(path+title.replace(".xlsx", ""))
        work_sheets = sheets.Worksheets[0]
        
        # Convert into PDF File
        work_sheets.ExportAsFixedFormat(0, path+title.replace(".xlsx", ""))
        sheets.Close()


    #method to calculate the expected AUM value by month, i.e., value 1 period hence
    #these variables are passed in...
    #short_rate = shorter term rate rate
    #short_term = short term rate period
    #long_rate = longer term rate
    #long_term = long term rate period
    #time_to_event = time from val date to event date
    
    #These are all calculations
    #rf_spread = difference between short and long-term risk-free (rf) rates
    #rftime_spread = difference between short and long-term risk-free (rf)maturity dates
    #incremental_period = difference between the actual period and short rateterm
    #inc_time_percent = incremental_period/rftime_spread
    #incremental_yield = rf_spread * inc_time_percent
    #incremtal_rf_rate = short_rate + incremental_yield
    
    #method to calculate the imterim rate of interest for use in the analysis
    def interim_rate(self, short_rate, long_rate, interval_years, short_term_num, long_term_num):
            
        #first, clac treasury yield (risk-free) spread
        rf_spread = round((float(long_rate) - float(short_rate))/100, 4)
        #second, calc rf term spread
        rftime_spread = long_term_num - short_term_num
        #third, calc incremental time period
        # incremental_period = time_to_event - short_term_num
        print("interval_years", interval_years, type(interval_years))
        incremental_period = round(interval_years - short_term_num, 4)
        #forth, calc incremental time period %
        inc_time_percent = incremental_period/rftime_spread
        #fifth, calc incremtnal yield
        incremental_yield = rf_spread * inc_time_percent
        #sixth, calc the effective or incremental rf rate for use in the analysis
        incremental_rf_rate = round(float(short_rate)/100 + incremental_yield, 4)

        print("FINAL STATS rf_spread:", rf_spread)
        print("FINAL STATS rftime_spread:", rftime_spread)
        print("FINAL STATS incremental_period:", incremental_period)
        print("FINAL STATS inc_time_percent:", inc_time_percent)
        print("FINAL STATS incremental_yield:", incremental_yield)
        print("FINAL STATS incremental_rf_rate:", incremental_rf_rate)
        title = "interest_rates.xlsx"
        vals = [rf_spread, rftime_spread, incremental_period, inc_time_percent, incremental_yield, incremental_rf_rate]
        # self.generate_excel_lattice(vals, title)
        ###RETURN incremental yield
        return incremental_rf_rate
    def generate_excel_interest_rates(self, data_list, title, rate_title):
        # create a new workbook object
        workbook = openpyxl.Workbook()

        # select the active worksheet
        worksheet = workbook.active

        # write the headers for data
        worksheet.append(['Date', 'Realtime Start', 'Realtime End', 'Value'])

        # print("DGS DATA LIST!!!!", data_list)

        # iterate through the rows in the data_list DataFrame
        for index, row in data_list.iterrows():
            # Retrieve the row at index and extract the date string
            row = data_list.iloc[index]
            date_string = row[0]
            # Convert the date string to a datetime object
            data_date = datetime.strptime(date_string, '%Y-%m-%d').date()
            if data_date >= self.start_date and data_date <= self.end_date:
                date = row['date']
                realtime_start = row['realtime_start']
                realtime_end = row['realtime_end']
                value = row['value']
                worksheet.append([date, realtime_start, realtime_end, value])

        # save the workbook
        workbook.save(title)