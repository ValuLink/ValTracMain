from forex_python.converter import CurrencyRates
from datetime import date

def get_exchange_rate(currency_1: str, currency_2: str, date: date) -> float:
    """
    Get the exchange rate from currency 1 to currency 2 for a specific date using forex-python library.
    
    Parameters:
    currency_1 (str): The currency you want to convert from.
    currency_2 (str): The currency you want to convert to.
    date (date): The date for which you want to get the exchange rate in yyyy-mm-dd format.
    
    Returns:
    float: The exchange rate from currency 1 to currency 2 on the specified date.
    """
    # Create a CurrencyRates object
    forex = CurrencyRates()

    # Get the exchange rate from currency 1 to currency 2 on the specified date
    exchange_rate = forex.get_rate(currency_1, currency_2, date)

    return exchange_rate
