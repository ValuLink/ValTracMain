from rest_framework import serializers
from .models import Volatility


# Volatility Serializer
class VolatilitySerializer(serializers.ModelSerializer):
    class Meta:
        model = Volatility
        # fields = '__all__'
        fields = [
            'id',
            'symbols',
            'annualized_volatilities',
            'average_annual_volatility',
            'start_date',
            'end_date',
            'valuation',
            'upload_time',
            'user',
        ]
        extra_kwargs = {
            'id': {
                'required': False
            },
            'symbols': {
                'required': False
            },
            'annualized_volatilities': {
                'required': False
            },
            'average_annual_volatility': {
                'required': False
            },
            'start_date': {
                'required': False
            },
            'end_date': {
                'required': False
            },
            'valuation': {
                'required': False
            },
            'upload_time': {
                'required': False
            },
            'user': {
                'required': False
            }
        }
        validators = []


# BusinessInfo Serializer
# class BusinessInfoSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = BusinessInfo
#         # fields = '__all__'
#         fields = [
#             'id',
#             'first_name',
#             'last_name',
#             'phone',
#             'email',
#             'business_name',
#             'business_url',
#             'industry',
#             'street',
#             'apartment',
#             'city',
#             'state',
#             'zip',
#             'country',
#             'show_facebook_help',
#             'show_help',
#             'enable_facebook',
#             'enable_instagram',
#             'enable_google',
#             'upload_time',
#             'user',
#         ]
#         extra_kwargs = {
#             'id': {
#                 'required': False
#             },
#             'first_name': {
#                 'required': False
#             },
#             'last_name': {
#                 'required': False
#             },
#             'phone': {
#                 'required': False
#             },
#             'email': {
#                 'required': False
#             },
#             'business_name': {
#                 'required': False
#             },
#             'business_url': {
#                 'required': False
#             },
#             'industry': {
#                 'required': False
#             },
#             'street': {
#                 'required': False
#             },
#             'apartment': {
#                 'required': False
#             },
#             'city': {
#                 'required': False
#             },
#             'state': {
#                 'required': False
#             },
#             'zip': {
#                 'required': False
#             },
#             'country': {
#                 'required': False
#             },
#             'show_facebook_help': {
#                 'required': False
#             },
#             'show_help': {
#                 'required': False
#             },
#             'enable_facebook': {
#                 'required': False
#             },
#             'enable_instagram': {
#                 'required': False
#             },
#             'enable_google': {
#                 'required': False
#             },
#             'upload_time': {
#                 'required': False
#             },
#             'user': {
#                 'required': False
#             }
#         }
#         validators = []
