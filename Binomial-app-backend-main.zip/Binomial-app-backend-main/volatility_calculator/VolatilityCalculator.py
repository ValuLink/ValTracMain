from valtrak.settings import ALPHA_VANTAGE_API_KEY

from alpha_vantage.timeseries import TimeSeries
import requests

import numpy as np
import math
import openpyxl

# Pdf conversion imports
from win32com import client
import pythoncom
import os

from .models import Volatility
# from valuation_creator.models import Valuation

class VolatilityCalculator:
    def __init__(self, symbols, start_date, end_date, trading_days, days_after_close, user):
        symbol_list = symbols.replace(" ", "").split(",") #remove spaces from string of stock symbols and Split symbol string into list by commas
        self.symbols = symbol_list #List of symbols
        self.start_date = start_date #Start date
        self.end_date = end_date #End Date
        self.trading_days = trading_days #Time Interval
        self.days_after_close = days_after_close #Time Interval
        self.user = user #user

    def get_stock_prices(self):
      # symbols = ['NVDA', 'RBLX', 'AAPL', 'META', 'MSFT']
      data_list = []
      # meta_data_list = []

      ts = TimeSeries(key=ALPHA_VANTAGE_API_KEY)
      # Get json object with the intraday data and another with  the call's metadata
      for symbol in self.symbols:
        # replace the "demo" apikey below with your own key from https://www.alphavantage.co/support/#api-key
        url = 'https://www.alphavantage.co/query?function=TIME_SERIES_DAILY_ADJUSTED&outputsize=full&symbol={}&apikey={}'.format(symbol, ALPHA_VANTAGE_API_KEY)
        r = requests.get(url)
        data = r.json()
        # data, meta_data = ts.get_intraday(symbol)
        data_list.append(data)
        # meta_data_list.append(meta_data)
      # print("ALPHA VANTAGE TIME SERIES TEST", type(data))
      return data_list

    #Create Binomial price tree here    
    def calculate_volatility(self):
        stock_prices_data = self.get_stock_prices()
        num_stocks = len(stock_prices_data)
        annualized_volatility_list = []

        for stock in range (0, num_stocks):
            volatility_list = np.zeros(int(self.trading_days), dtype=np.float64)
            # print('LIST LENGTH', len(stock_prices_data))
            # print("stock_prices_data[stock]['Time Series (Daily)']", stock_prices_data[stock]['Time Series (Daily)'])
            stock_price_date_list = list(stock_prices_data[stock]['Time Series (Daily)'].keys())

            stock_price_dict = stock_prices_data[stock]['Time Series (Daily)']
            # print('DATES LIST !!!!', stock_price_date_list, type(stock_price_date_list))
            for val in range (0, volatility_list.size):
                if val+2+self.days_after_close < len(stock_price_date_list): #Check if adjusted index is out of range for number of dates
                    date = stock_price_date_list[val+1+self.days_after_close]
                    previous_date = stock_price_date_list[val+2+self.days_after_close]
                    # print('DATES!!!!', date, previous_date)
                    log_val = math.log(float(stock_price_dict[date]['5. adjusted close'])/float(stock_price_dict[previous_date]['5. adjusted close']))
                    # volatility_list[0][val] = val
                    # volatility_list[1][val] = date_list[val]
                    volatility_list[val] = log_val
            annualized_volatility_list.append(round(np.std(volatility_list)*math.sqrt(252)*100, 2))
        print("annualized_volatility list!!!!", len(annualized_volatility_list), annualized_volatility_list)
        average_annual_volatility = np.sum(annualized_volatility_list)/len(annualized_volatility_list)
        print("average_annual_volatility!!!!", average_annual_volatility)

        title = "annualized-volatility.xlsx"
        self.generate_excel_lattice(annualized_volatility_list, average_annual_volatility, title)
        return average_annual_volatility #call valuation method - see line 116

    def generate_excel_lattice(self, vals, average_annual_volatility, title):
        #print binomial tree results to Excel
        #transpose arrays

         # Save to Database
        volatility = Volatility(
            symbols=self.symbols,
            start_date=self.start_date,
            end_date=self.end_date,
            average_annual_volatility=average_annual_volatility,
            annualized_volatilities=vals,
            # valuation=val_obj,
            user=self.user)
        volatility.save()
        print("volatility SAVED", volatility.id)
        print("annualized_volatility list!!!!",  vals)
        wb = openpyxl.Workbook()
        sheet = wb.active
        c1= c1 = sheet.cell(row=1,column=1) #cell location - no zero indexing in Excel
        c1.value = "Annualized Volatilities" #affix value to cell location
        # col+=1
        # col = 0 #column indicator
        for i in range(0, len(vals)): #interates over each array element in stockvalue array

            c2 = sheet.cell(row=2,column=i+1) #cell location - no zero indexing in Excel
            c2.value = self.symbols[i] #affix value to cell location
            c3 = sheet.cell(row=3,column=i+1) #cell location - no zero indexing in Excel
            c3.value = vals[i] #affix value to cell location
        wb.save(title) 
        wb.close()
        # Convert to pdf and export
        excel = client.Dispatch("Excel.Application",pythoncom.CoInitialize())
        path =  os.getcwd().replace('\'','\\') + '\\'
        # Read Excel File
        sheets = excel.Workbooks.Open(path+title.replace(".xlsx", ""))
        work_sheets = sheets.Worksheets[0]
        
        # Convert into PDF File
        work_sheets.ExportAsFixedFormat(0, path+title.replace(".xlsx", ""))
        sheets.Close()
        