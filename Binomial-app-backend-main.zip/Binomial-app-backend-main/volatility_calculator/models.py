from django.db import models
from valuation_creator.models import Valuation
from django.contrib.auth.models import User

# Create your models here.
# Volatility Creative
class Volatility(models.Model):
    # Instrument
    symbols = models.TextField(max_length=100, blank=True)
    annualized_volatilities = models.TextField(max_length=100, blank=True)
    average_annual_volatility = models.TextField(max_length=100, blank=True)
    start_date = models.TextField(max_length=100, blank=True)
    end_date = models.TextField(max_length=100, blank=True)
    upload_time = models.DateTimeField(auto_now_add=True, null=True)
    #Corresponds to user Id
    valuation = models.ForeignKey(Valuation,
                             related_name="Volatility",
                             on_delete=models.CASCADE,
                             null=True)
    user = models.ForeignKey(User,
                             related_name="Volatility",
                             on_delete=models.CASCADE,
                             null=True)

    class Meta:
        verbose_name = 'Volatility'