from django.urls import path
from . import views
from django.views.decorators.csrf import csrf_exempt
from rest_framework import routers
from .api import VolatilityViewSet

# Register api Routes
router = routers.DefaultRouter()
router.register('volatility', VolatilityViewSet, 'volatility')

urlpatterns = router.urls + [
  path('create-volatility/',
    csrf_exempt(views.create_volatility),
    name='create-volatility/'),
]
