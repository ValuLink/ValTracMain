
import openpyxl
from .VolatilityCalculator import VolatilityCalculator
# import time
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, renderer_classes
from rest_framework.renderers import JSONRenderer
from datetime import datetime, date

@api_view(('POST', ))
@renderer_classes((JSONRenderer, ))
def create_volatility(request):
    if request.method == "POST":
        # Check if user is logged in
        if request.user.is_authenticated:

            # fields taken from form
            symbols =  request.POST["symbols"] #symbols
            start_date =  datetime.strptime(request.POST["start_date"], '%Y-%m-%d').date() #start_date
            end_date =  datetime.strptime(request.POST["end_date"], '%Y-%m-%d').date() #end_date
            current_date = date.today()
            time_interval = end_date - start_date
            trading_days = int(time_interval.days * (252/365.25)) #trading days in interval
            days_after_close = int((current_date - end_date).days * (252/365.25)) # trading days after close

            print("trading_days and ", trading_days, days_after_close)

            # Run Code
            volatility = VolatilityCalculator(symbols, start_date, end_date, trading_days, days_after_close, request.user).calculate_volatility()
            print("VOLATILITY!!!!", volatility)

            # End Run Code
            return Response(volatility, status=status.HTTP_200_OK)
        else:
            # Return Auth error if user is not logged in
            return Response({"error": "Auth Error"},
                            status=status.HTTP_400_BAD_REQUEST)
    else:
        # Return Error if invalid method
        return Response({"error": "Method not allowed"},
                        status=status.HTTP_400_BAD_REQUEST)
