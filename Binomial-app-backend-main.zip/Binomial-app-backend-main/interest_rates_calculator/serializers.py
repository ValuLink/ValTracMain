from rest_framework import serializers
from .models import InterestRates


# InterestRates Serializer
class InterestRatesSerializer(serializers.ModelSerializer):
    class Meta:
        model = InterestRates
        # fields = '__all__'
        fields = [
            'id',
            'risk_free_spread',
            'risk_free_time_spread',
            'incremental_time_percent',
            'incremental_yield',
            'incremental_risk_free_rate',
            'start_date',
            'end_date',
            'short_term',
            'long_term',
            'valuation',
            'upload_time',
            'user',
        ]
        extra_kwargs = {
            'id': {
                'required': False
            },
            'risk_free_spread': {
                'required': False
            },
            'risk_free_time_spread': {
                'required': False
            },
            'incremental_time_percent': {
                'required': False
            },
            'incremental_yield': {
                'required': False
            },
            'incremental_risk_free_rate': {
                'required': False
            },
            'start_date': {
                'required': False
            },
            'end_date': {
                'required': False
            },
            'short_term': {
                'required': False
            },
            'long_term': {
                'required': False
            },
            'valuation': {
                'required': False
            },
            'upload_time': {
                'required': False
            },
            'user': {
                'required': False
            }
        }
        validators = []


# BusinessInfo Serializer
# class BusinessInfoSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = BusinessInfo
#         # fields = '__all__'
#         fields = [
#             'id',
#             'first_name',
#             'last_name',
#             'phone',
#             'email',
#             'business_name',
#             'business_url',
#             'industry',
#             'street',
#             'apartment',
#             'city',
#             'state',
#             'zip',
#             'country',
#             'show_facebook_help',
#             'show_help',
#             'enable_facebook',
#             'enable_instagram',
#             'enable_google',
#             'upload_time',
#             'user',
#         ]
#         extra_kwargs = {
#             'id': {
#                 'required': False
#             },
#             'first_name': {
#                 'required': False
#             },
#             'last_name': {
#                 'required': False
#             },
#             'phone': {
#                 'required': False
#             },
#             'email': {
#                 'required': False
#             },
#             'business_name': {
#                 'required': False
#             },
#             'business_url': {
#                 'required': False
#             },
#             'industry': {
#                 'required': False
#             },
#             'street': {
#                 'required': False
#             },
#             'apartment': {
#                 'required': False
#             },
#             'city': {
#                 'required': False
#             },
#             'state': {
#                 'required': False
#             },
#             'zip': {
#                 'required': False
#             },
#             'country': {
#                 'required': False
#             },
#             'show_facebook_help': {
#                 'required': False
#             },
#             'show_help': {
#                 'required': False
#             },
#             'enable_facebook': {
#                 'required': False
#             },
#             'enable_instagram': {
#                 'required': False
#             },
#             'enable_google': {
#                 'required': False
#             },
#             'upload_time': {
#                 'required': False
#             },
#             'user': {
#                 'required': False
#             }
#         }
#         validators = []
