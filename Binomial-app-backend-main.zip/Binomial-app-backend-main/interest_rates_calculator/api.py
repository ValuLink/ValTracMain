from .models import InterestRates
from rest_framework import viewsets, permissions, status, filters
# from rest_framework.response import Response
# from rest_framework.views import APIView
from .serializers import InterestRatesSerializer
# from rest_framework.exceptions import APIException
# from django.conf import settings
# from django.http import Http404
# import stripe

# InterestRates Viewset
class InterestRatesViewSet(viewsets.ModelViewSet):
    queryset = InterestRates.objects.all()
    permission_classes = [
        permissions.IsAuthenticated
        #permissions.AllowAny
    ]
    serializer_class = InterestRatesSerializer
    filter_backends = [filters.OrderingFilter]
    ordering_fields = ['id',]
    ordering = ['-id',]

    def get_queryset(self):
        return self.request.user.InterestRates.all()

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)
