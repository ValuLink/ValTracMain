from django.db import models
from valuation_creator.models import Valuation
from django.contrib.auth.models import User

# Create your models here.
# InterestRates Creative
class InterestRates(models.Model):
    # Instrument
    risk_free_spread = models.TextField(max_length=100, blank=True)
    risk_free_time_spread = models.TextField(max_length=100, blank=True)
    incremental_period = models.TextField(max_length=100, blank=True)
    incremental_time_percent = models.TextField(max_length=100, blank=True)
    incremental_yield = models.TextField(max_length=100, blank=True)
    incremental_risk_free_rate = models.TextField(max_length=100, blank=True)
    short_term = models.TextField(max_length=100, blank=True)
    long_term = models.TextField(max_length=100, blank=True)
    start_date = models.TextField(max_length=100, blank=True)
    end_date = models.TextField(max_length=100, blank=True)
    upload_time = models.DateTimeField(auto_now_add=True, null=True)
    #Corresponds to user Id
    valuation = models.ForeignKey(Valuation,
                             related_name="InterestRates",
                             on_delete=models.CASCADE,
                             null=True)
    user = models.ForeignKey(User,
                             related_name="InterestRates",
                             on_delete=models.CASCADE,
                             null=True)

    class Meta:
        verbose_name = 'InterestRates'