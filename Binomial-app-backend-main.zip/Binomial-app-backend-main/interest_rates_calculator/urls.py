from django.urls import path
from . import views
from django.views.decorators.csrf import csrf_exempt
from rest_framework import routers
from .api import InterestRatesViewSet

# Register api Routes
router = routers.DefaultRouter()
router.register('interest-rates', InterestRatesViewSet, 'interest-rates')

urlpatterns = router.urls + [
  path('create-interest-rates/',
    csrf_exempt(views.create_interest_rates),
    name='create-interest-rates/'),
]
