
import openpyxl
from .InterestCalculator import InterestCalculator
# import time
from rest_framework import status
from rest_framework.response import Response
from rest_framework.decorators import api_view, renderer_classes
from rest_framework.renderers import JSONRenderer
from datetime import datetime

@api_view(('POST', ))
@renderer_classes((JSONRenderer, ))
def create_interest_rates(request):
    if request.method == "POST":
        # Check if user is logged in
        if request.user.is_authenticated:

            # fields taken from form
            short_term =  request.POST["short_term"] #short_term
            long_term =  request.POST["long_term"] #long_term
            start_date =  datetime.strptime(request.POST["start_date"], '%Y-%m-%d').date() #start_date
            end_date =  datetime.strptime(request.POST["end_date"], '%Y-%m-%d').date() #end_date
            start_date_string =  start_date.strftime('%Y-%m-%d') #start_date
            end_date_string =  end_date.strftime('%Y-%m-%d') #end_date

            time_interval = end_date - start_date
            time_to_event = int((datetime.now().date() - end_date).days  * (1/365.25))
            # interval_days = int(time_interval.years) #trading days in interval
            interval_years = int(time_interval.days * (1/365.25)) #number of years to maturity #trading days in interval
            print("interval_years", interval_years, type(interval_years))
            # Run Code
            interest_rate_data = InterestCalculator(start_date, end_date, start_date_string, end_date_string, interval_years, short_term, long_term, request.user).get_interest_rates()

            # End Run Code
            return Response(interest_rate_data, status=status.HTTP_200_OK)
        else:
            # Return Auth error if user is not logged in
            return Response({"error": "Auth Error"},
                            status=status.HTTP_400_BAD_REQUEST)
    else:
        # Return Error if invalid method
        return Response({"error": "Method not allowed"},
                        status=status.HTTP_400_BAD_REQUEST)
