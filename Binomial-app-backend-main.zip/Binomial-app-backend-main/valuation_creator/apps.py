from django.apps import AppConfig


class ValuationConfig(AppConfig):
    name = 'valuation_creator'
