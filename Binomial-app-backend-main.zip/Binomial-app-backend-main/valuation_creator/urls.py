

from rest_framework import routers
from .api import ValuationViewSet, AgentValuationViewSet

# Register api Routes
router = routers.DefaultRouter()
router.register('valuation', ValuationViewSet, 'valuation')
router.register('agent-valuation', AgentValuationViewSet, 'agent-valuation')
# router.register('business-info', BusinessInfoViewSet, 'business-info')

urlpatterns = router.urls
