from django.conf import settings
from django.contrib.auth.models import User
from django.db import models
from datetime import datetime
from django.core.validators import MaxValueValidator, MinValueValidator
# from django.contrib.postgres.fields import ArrayField
from decimal import *
# from payments.models import Address
from accounts.models import Agent



# Valuation Creative
class Valuation(models.Model):
    # Instrument
    company_name = models.TextField(max_length=100, blank=True)
    instrument_name = models.TextField(max_length=100, blank=True)
    public_company_ticker = models.TextField(max_length=100, blank=True)
    currency_one = models.TextField(max_length=100, blank=True)
    currency_two = models.TextField(max_length=100, blank=True)
    credit_spread = models.TextField(max_length=100, blank=True)
    valuation_date = models.TextField(max_length=100, blank=True)
    maturity_date = models.TextField(max_length=100, blank=True)
    inception_date = models.TextField(max_length=100, blank=True)
    number_of_steps = models.TextField(max_length=100, blank=True)
    stated_principal = models.TextField(max_length=100, blank=True)
    offering_proceeds = models.TextField(max_length=100, blank=True)
    initial_conversion_price = models.TextField(max_length=100, blank=True)
    # Market
    usd_to_cad_fx_rate = models.TextField(max_length=100, blank=True)
    nominal_interest_rate = models.TextField(max_length=100, blank=True)
    interest_rate_accrual = models.TextField(max_length=100, blank=True)
    accrual_frequency = models.TextField(max_length=100, blank=True)
    interest_rate_cash_payment = models.TextField(max_length=100, blank=True)
    interest_case = models.TextField(max_length=100, blank=True)
    accrual_date_one = models.TextField(max_length=100, blank=True)
    accrual_date_two = models.TextField(max_length=100, blank=True)
    stock_price = models.TextField(max_length=100, blank=True)
    volatility = models.TextField(max_length=100, blank=True)
    risk_free_rate = models.TextField(max_length=100, blank=True)
    dividend_yield = models.TextField(max_length=100, blank=True)
    ccc_rate = models.TextField(max_length=100, blank=True)
    # Fields for mandatory_conversion_percent_condition
    mandatory_conversion_percent_condition = models.TextField(max_length=100, blank=True)
    mandatory_conversion_percentage = models.TextField(max_length=100, blank=True)
    fixed_conversion_price = models.TextField(max_length=100, blank=True)
    volatility_case = models.TextField(max_length=100, blank=True)
    volatility_date_1 = models.TextField(max_length=100, blank=True)
    volatility_date_2 = models.TextField(max_length=100, blank=True)
    volatility_time_period = models.TextField(max_length=100, blank=True)
                                                               
    upload_time = models.DateTimeField(auto_now_add=True, null=True)
    #Corresponds to user Id
    user = models.ForeignKey(User,
                             related_name="Valuation",
                             on_delete=models.CASCADE,
                             null=True)
    agent = models.ForeignKey(Agent,
                             related_name="Valuation",
                             on_delete=models.CASCADE,
                             null=True)

    class Meta:
        verbose_name = 'Valuation'


# Google Search Ad Creative
class BusinessInfo(models.Model):
    first_name = models.TextField(max_length=100, blank=True)
    last_name = models.TextField(max_length=100, blank=True)
    phone = models.TextField(max_length=100, blank=True)
    email = models.TextField(max_length=100, blank=True)
    business_name = models.TextField(max_length=100, blank=True)
    industry = models.TextField(max_length=100, blank=True)
    business_url = models.TextField(max_length=100, blank=True)
    street = models.TextField(max_length=100, blank=True)
    apartment = models.TextField(max_length=100, blank=True)
    city = models.TextField(max_length=100, blank=True)
    state = models.TextField(max_length=100, blank=True)
    country = models.TextField(max_length=100, blank=True)
    # country = CountryField(multiple=False)
    zip = models.TextField(max_length=100, blank=True)
    show_facebook_help = models.TextField(max_length=100, blank=True)
    show_help = models.TextField(max_length=100, blank=True)
    enable_facebook = models.TextField(max_length=100, blank=True)
    enable_instagram = models.TextField(max_length=100, blank=True)
    enable_google = models.TextField(max_length=100, blank=True)

    upload_time = models.DateTimeField(auto_now_add=True)
    #Corresponds to user Id
    user = models.ForeignKey(User,
                             related_name="BusinessInfo",
                             on_delete=models.CASCADE,
                             null=True)

    class Meta:
        verbose_name = 'BusinessInfo'

