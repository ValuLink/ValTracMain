from rest_framework import serializers
from .models import Valuation


# Valuation Serializer
class ValuationSerializer(serializers.ModelSerializer):
    class Meta:
        model = Valuation
        # fields = '__all__'
        fields = [
            'id',
            'company_name',
            'instrument_name',
            'public_company_ticker',
            'currency_one',
            'currency_two',
            'credit_spread',
            'public_company_ticker',
            'valuation_date',
            'maturity_date',
            'inception_date',
            'number_of_steps',
            'stated_principal',
            'offering_proceeds',
            'initial_conversion_price',
            'usd_to_cad_fx_rate',
            'nominal_interest_rate',
            'interest_rate_accrual',
            'accrual_frequency',
            'interest_rate_cash_payment',
            'interest_case',
            'accrual_date_one',
            'accrual_date_two',
            'stock_price',
            'volatility',
            'volatility_case',
            'volatility_date_1',
            'volatility_date_2',
            'volatility_time_period',
            'risk_free_rate',
            'dividend_yield',
            'ccc_rate',
            'mandatory_conversion_percent_condition',
            'mandatory_conversion_percentage',
            'fixed_conversion_price',
            'upload_time',
            'user',
            'agent',
        ]
        extra_kwargs = {
            'id': {
                'required': False
            },
            'company_name': {
                'required': False
            },
            'instrument_name': {
                'required': False
            },
            'public_company_ticker': {
                'required': False
            },
            'currency_one': {
                'required': False
            },
            'currency_two': {
                'required': False
            },
            'credit_spread': {
                'required': False
            },
            'valuation_date': {
                'required': False
            },
            'maturity_date': {
                'required': False
            },
            'inception_date': {
                'required': False
            },
            'number_of_steps': {
                'required': False
            },
            'stated_principal': {
                'required': False
            },
            'offering_proceeds': {
                'required': False
            },
            'initial_conversion_price': {
                'required': False
            },
            'usd_to_cad_fx_rate': {
                'required': False
            },
            'nominal_interest_rate': {
                'required': False
            },
            'interest_rate_accrual': {
                'required': False
            },
            'accrual_frequency': {
                'required': False
            },
            'interest_rate_cash_payment': {
                'required': False
            },
            'interest_case': {
                'required': False
            },
            'accrual_date_one': {
                'required': False
            },
            'accrual_date_two': {
                'required': False
            },
            'stock_price': {
                'required': False
            },
            'volatility': {
                'required': False
            },
            'volatility_case': {
                'required': False
            },
            'volatility_date_1': {
                'required': False
            },
            'volatility_date_2': {
                'required': False
            },
            'volatility_time_period': {
                'required': False
            },
            'risk_free_rate': {
                'required': False
            },
            'dividend_yield': {
                'required': False
            },
            'ccc_rate': {
                'required': False
            },
            'mandatory_conversion_percent_condition': {
                'required': False
            },
            'mandatory_conversion_percentage': {
                'required': False
            },
            'fixed_conversion_price': {
                'required': False
            },
            'upload_time': {
                'required': False
            },
            'user': {
                'required': False
            },
            'agent': {
                'required': False
            }
        }
        validators = []


# BusinessInfo Serializer
# class BusinessInfoSerializer(serializers.ModelSerializer):
#     class Meta:
#         model = BusinessInfo
#         # fields = '__all__'
#         fields = [
#             'id',
#             'first_name',
#             'last_name',
#             'phone',
#             'email',
#             'business_name',
#             'business_url',
#             'industry',
#             'street',
#             'apartment',
#             'city',
#             'state',
#             'zip',
#             'country',
#             'show_facebook_help',
#             'show_help',
#             'enable_facebook',
#             'enable_instagram',
#             'enable_google',
#             'upload_time',
#             'user',
#         ]
#         extra_kwargs = {
#             'id': {
#                 'required': False
#             },
#             'first_name': {
#                 'required': False
#             },
#             'last_name': {
#                 'required': False
#             },
#             'phone': {
#                 'required': False
#             },
#             'email': {
#                 'required': False
#             },
#             'business_name': {
#                 'required': False
#             },
#             'business_url': {
#                 'required': False
#             },
#             'industry': {
#                 'required': False
#             },
#             'street': {
#                 'required': False
#             },
#             'apartment': {
#                 'required': False
#             },
#             'city': {
#                 'required': False
#             },
#             'state': {
#                 'required': False
#             },
#             'zip': {
#                 'required': False
#             },
#             'country': {
#                 'required': False
#             },
#             'show_facebook_help': {
#                 'required': False
#             },
#             'show_help': {
#                 'required': False
#             },
#             'enable_facebook': {
#                 'required': False
#             },
#             'enable_instagram': {
#                 'required': False
#             },
#             'enable_google': {
#                 'required': False
#             },
#             'upload_time': {
#                 'required': False
#             },
#             'user': {
#                 'required': False
#             }
#         }
#         validators = []
