from .models import Valuation
from accounts.models import Agent
from rest_framework import viewsets, permissions, status, filters
# from rest_framework.response import Response
# from rest_framework.views import APIView
from .serializers import ValuationSerializer
# from rest_framework.exceptions import APIException
# from django.conf import settings
# from django.http import Http404
# import stripe


# Valuation Viewset
class ValuationViewSet(viewsets.ModelViewSet):
    queryset = Valuation.objects.all()
    permission_classes = [
        permissions.IsAuthenticated
        #permissions.AllowAny
    ]
    serializer_class = ValuationSerializer
    filter_backends = [filters.OrderingFilter]
    ordering_fields = ['id',]
    ordering = ['-id',]

    def get_queryset(self):
        return self.request.user.Valuation.all()

    def perform_create(self, serializer):
        serializer.save(user=self.request.user)

class AgentValuationViewSet(viewsets.ModelViewSet):
    queryset = Valuation.objects.all()
    permission_classes = [permissions.IsAuthenticated]
    serializer_class = ValuationSerializer
    filter_backends = [filters.OrderingFilter]
    ordering_fields = ['id']
    ordering = ['-id']

    def get_queryset(self):
        user = self.request.user
        if hasattr(user, 'agent') and user.agent.is_agent:
            return Valuation.objects.filter(agent=user.agent)
        return Valuation.objects.none()

    def perform_create(self, serializer):
        user = self.request.user
        if hasattr(user, 'agent') and user.agent.is_agent:
            serializer.save(agent=user.agent, user=user)
        else:
            serializer.save(user=user)
 

# BusinessInfo Viewset
# class BusinessInfoViewSet(viewsets.ModelViewSet):
#     queryset = BusinessInfo.objects.all()
#     permission_classes = [
#         permissions.IsAuthenticated
#         # permissions.AllowAny
#     ]
#     serializer_class = BusinessInfoSerializer
#     filter_backends = [filters.OrderingFilter]
#     ordering_fields = ['id',]
#     ordering = ['-id',]
#     def get_queryset(self):
#         return self.request.user.BusinessInfo.all()

#     def perform_create(self, serializer):
#         serializer.save(user=self.request.user)


 