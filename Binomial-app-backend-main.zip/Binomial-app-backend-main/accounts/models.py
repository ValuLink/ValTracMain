from django.db import models
from django.contrib.auth.models import User

# Create your models here.
# Agent Creative
class Agent(models.Model):
    # Instrument
    is_agent = models.TextField(max_length=10, blank=True)
    user = models.ForeignKey(User,
                             related_name="Agent",
                             on_delete=models.CASCADE,
                             null=True)

    class Meta:
        verbose_name = 'Agent'
