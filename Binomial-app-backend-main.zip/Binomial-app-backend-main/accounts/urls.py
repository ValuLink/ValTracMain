from django.urls import path, include
from django.views.decorators.csrf import csrf_exempt

from .api import RegisterAPI, LoginAPI, UserAPI, AgentAPI
from knox import views as knox_views
from .views import ChangePasswordView
from rest_framework import routers

# from .views import exchange_token, get_user_social_auth
# Register api Routes
router = routers.DefaultRouter()
router.register('agent', AgentAPI, 'agent')

urlpatterns = [
    path('accounts/', include('django.contrib.auth.urls')),
    path('auth', include('knox.urls')),
    path('auth/register', RegisterAPI.as_view()),
    path('auth/login', LoginAPI.as_view()),
    # path('login/', include('rest_social_auth.urls_knox')),
    path('auth/user', UserAPI.as_view()),
    path('auth/logout', knox_views.LogoutView.as_view(), name='knox_logout'),
    path('change-password', ChangePasswordView.as_view(), name='change-password'),
] + router.urls
