from django.test import TestCase
import pytest

from contextlib import contextmanager
import json
import re
from urllib.parse import urlparse, parse_qs

from rest_framework.test import APITestCase

# This is the responses library mentioned in the article, which
# provides RequestsMock
import responses

from requests.exceptions import HTTPError
from requests.models import Response
from social_core.backends import facebook, google

from accounts.models import User
# import tests.fixtures as fixtures

def setUp():
    User.objects.create(username='test1', password='1234')
    User.objects.create(username='test2', password='1234')
    User.objects.create(username='test3', password='1234')

def get_users():
    # get API response
    # response = client.get(reverse('get_post_puppies'))
    # get data from db
    users = User.objects.all()
    # serializer = UserSerializer(puppies, many=True)
    print("USERS", users, users.len())
    assert users.len() >= 2
    # assert (response.data, serializer.data)
    # assert (response.status_code, status.HTTP_200_OK)

